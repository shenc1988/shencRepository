package com.example.myapplication;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.SurfaceView;
import android.view.WindowManager;

import com.example.myapplication.event.TouchEvent;
import com.example.myapplication.object.GameMap;
import com.example.myapplication.object.Land;

public class SceneSurfaceView extends SurfaceView {

    // 画面表示用
    private Paint paint = new Paint();
    private Canvas canvas;

    // 屏幕高度
    private int screenHeight;
    // 屏幕宽度
    private int screenWidth;

    // 每个单元格标准尺寸
    static final int BASE_SIZE = 100;

    // 地图位移记录
    // 手向右滑动，数据减少
    int mapShiftX = 0;
    int mapShiftY = 0;
    // 地图位移最大值
    int mapShiftMaxX = 0;
    int mapShiftMaxY = 0;

    // 区分点击与拖动事件
    private boolean isClick;
    // 拖动结束位置
    int downX = 0;
    int downY = 0;
    // 拖动起始结束时间
    private long startTime = 0;
    private long endTime = 0;

    // 声明图片
    Bitmap bitmap_land;
    Bitmap bitmap_selected;

    // 地图类
    GameMap gameMap = new GameMap();

    public SceneSurfaceView(Context context) {
        super(context);
        // 设定调用onDraw方法
        setWillNotDraw(false);

        Point point = new Point();
        //获取窗口管理器
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        wm.getDefaultDisplay().getSize(point);
        // 屏幕宽度
        screenWidth = point.x;
        // 屏幕高度
        screenHeight = point.y;
        // 地图位移最大值
        mapShiftMaxX = -((gameMap.getSize() * BASE_SIZE - screenWidth) > 0 ? (gameMap.getSize() * BASE_SIZE - screenWidth) : 0);
        mapShiftMaxY = -((gameMap.getSize() * BASE_SIZE - screenHeight) > 0 ? (gameMap.getSize() * BASE_SIZE - screenHeight) : 0);

        // 加载图片
        Resources res = context.getResources();
        bitmap_land = BitmapFactory.decodeResource(res, R.drawable.land);
        bitmap_selected = BitmapFactory.decodeResource(res, R.drawable.selected);

    }

    @Override
    protected void onDraw(Canvas canvas) {

        this.canvas = canvas;

        super.onDraw(canvas);
        // 画面表示
        onDraw_Main();
    }

    private void onDraw_Main() {
        // 图片裁剪
        Rect src=new Rect(0,0,0+BASE_SIZE,0+BASE_SIZE);

        for (int i = 0; i < gameMap.getLandList().size(); i++){
            Land land = gameMap.getLandList().get(i);
            canvas.drawBitmap(bitmap_land, src,
                    new RectF(BASE_SIZE * land.getX() + mapShiftX,
                            BASE_SIZE * land.getY() + mapShiftY,
                            BASE_SIZE * land.getX() + BASE_SIZE + mapShiftX,
                            BASE_SIZE * land.getY() + BASE_SIZE + mapShiftY), paint);
            if (land.isSelected()) {
                canvas.drawBitmap(bitmap_selected, src,
                        new RectF(BASE_SIZE * land.getX() + mapShiftX,
                                BASE_SIZE * land.getY() + mapShiftY,
                                BASE_SIZE * land.getX() + BASE_SIZE + mapShiftX,
                                BASE_SIZE * land.getY() + BASE_SIZE + mapShiftY), paint);
            }
        }
    }

    // 触摸屏响应
    @Override
    public boolean onTouchEvent(MotionEvent event) {

        switch(event.getAction()){

            case MotionEvent.ACTION_DOWN:
                downX = (int) event.getX();
                downY = (int) event.getY();

                // 当按下的时候设置isClick为false
                isClick = false;
                startTime = System.currentTimeMillis();

                break;
            case MotionEvent.ACTION_MOVE:

                //当按钮被移动的时候设置isClick为false
                isClick = false;

                int moveX = (int) event.getX() - downX;
                int moveY = (int) event.getY() - downY;

                mapShiftX = mapShiftX + moveX;
                mapShiftY = mapShiftY + moveY;
                // 控制画面移动范围
                if (mapShiftX < mapShiftMaxX){
                    mapShiftX = mapShiftMaxX;
                } else if (mapShiftX > 0){
                    mapShiftX = 0;
                }
                if (mapShiftY < mapShiftMaxY){
                    mapShiftY = mapShiftMaxY;
                } else if (mapShiftY > 0){
                    mapShiftY = 0;
                }

                downX = (int) event.getX();
                downY = (int) event.getY();

                break;
            case MotionEvent.ACTION_UP:
                endTime = System.currentTimeMillis();
                // 当从点击到弹起小于半秒的时候,则判断为点击,如果超过则不响应点击事件
                if ((endTime - startTime) < 0.2 * 1000L) {
                    isClick = true;
                } else {
                    isClick = false;
                }
                break;
        }

        // 点击事件
        if (isClick) {
            for (int i = 0; i < gameMap.getLandList().size(); i++) {
                Land land = gameMap.getLandList().get(i);
                if ((BASE_SIZE * land.getX() + mapShiftX) < downX &&
                        (BASE_SIZE * land.getX() + BASE_SIZE + mapShiftX) > downX &&
                        (BASE_SIZE * land.getY() + mapShiftY) < downY &&
                        (BASE_SIZE * land.getY() + BASE_SIZE + mapShiftY) > downY) {
                    land.setSelected(true);
                }
            }
        }

        // 重新绘制画面
        invalidate();

        // 不能用return super.onTouchEvent(event);
        return true;
    }
}
