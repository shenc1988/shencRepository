package com.example.myapplication.event;

public class Logic {
    public void setMap(int mapSize){

    }
}
