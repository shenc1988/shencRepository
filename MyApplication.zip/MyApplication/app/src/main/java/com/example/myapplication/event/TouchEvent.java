package com.example.myapplication.event;

import android.view.MotionEvent;

public class TouchEvent {
    public static void onTouchEvent(MotionEvent event){

    }
}
