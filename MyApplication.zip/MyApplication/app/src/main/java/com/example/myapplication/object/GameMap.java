package com.example.myapplication.object;

import java.util.ArrayList;

public class GameMap {

    // 地图尺寸
    static int size = 5;

    // 地图
    static ArrayList<Land> landList = new ArrayList<Land>();

    public static int getSize() {
        return size;
    }

    public static void setSize(int size) {
        GameMap.size = size;
    }

    public static ArrayList<Land> getLandList() {
        return landList;
    }

    public static void setLandList(ArrayList<Land> landList) {
        GameMap.landList = landList;
    }

    // 生成地图
    public static void createMap(){
        for (int i = 0; i < size; i++){
            for (int j = 0; j < size; j++){
                Land land = new Land(i, j);
                landList.add(land);
            }
        }
    }
}
