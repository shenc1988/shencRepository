package com.example.myapplication.object;

import java.util.ArrayList;

public class GamePlayers {

    // 玩家与AI
    static ArrayList<Player> playerList = new ArrayList<Player>();

    public static ArrayList<Player> getPlayerList() {
        return playerList;
    }

    public static void setPlayerList(ArrayList<Player> playerList) {
        GamePlayers.playerList = playerList;
    }

    // 通过playerID获得player
    public static Player getPlayerByID(int ID) {
        for (Player player : playerList){
            if (player.getID() == ID){
                return player;
            }
        }
        return null;
    }

    // 至少有两个player
    public static boolean hasAtLeastTwoPlayer() {
        int i = 0;
        for (Player player : playerList){
            if (player.isJoined()){
                i++;
            }
        }
        if(i >= 2){
            return true;
        }
        return false;
    }
}
