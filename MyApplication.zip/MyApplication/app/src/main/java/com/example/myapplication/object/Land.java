package com.example.myapplication.object;

public class Land {

    // 坐标序号
    // 例：
    // (0,0)(0,1)(0,2)
    // (1,0)(1,1)(1,2)
    // (2,0)(2,1)(2,2)
    private int x, y;

    // 是否选择
    private boolean isSelected = false;

    public Land(int x, int y) {
        this.setX(x);
        this.setY(y);
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }
}
