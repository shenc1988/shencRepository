package com.example.myapplication.object;

public class Player {

    // ID
    private int ID;

    // 是否加入游戏
    private boolean isJoined;

    // 是否为AI
    private boolean isAI;

    public Player(int ID, boolean isJoined, boolean isAI) {
        this.ID = ID;
        this.isJoined = isJoined;
        this.isAI = isAI;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public boolean isAI() {
        return isAI;
    }

    public void setAI(boolean AI) {
        isAI = AI;
    }

    public boolean isJoined() {
        return isJoined;
    }

    public void setJoined(boolean joined) {
        isJoined = joined;
    }
}
