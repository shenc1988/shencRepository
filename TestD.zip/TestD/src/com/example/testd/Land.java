package com.example.testd;

import java.util.ArrayList;
import java.util.List;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;

public class Land {

	int PIXEL_UNIT = 100;
	
	private int x, y;
	private List<Land> way = new ArrayList<Land>();
	
	private boolean canMove = false;
	
	private boolean canBuy = false;
	
	private int landType = 0;
	
	private boolean hasSelected = false;
	
	private boolean hasUnit = false;
	private Unit unit;
	
	private boolean hasTown = false;
	private Town town;

	public Land(int x, int y) {
		this.setX(x);
		this.setY(y);
	}
	
	public void draw(Bitmap bmpLand, Canvas canvas, Paint paint) {
		canvas.drawBitmap(bmpLand, x*PIXEL_UNIT, y*PIXEL_UNIT, paint);
	}
	
	public void drawMoveFlag(Bitmap bmpLand, Canvas canvas, Paint paint) {
		canvas.drawBitmap(bmpLand, x*PIXEL_UNIT+PIXEL_UNIT/2, y*PIXEL_UNIT, paint);
	}
	
	public void drawOwnFlag(Bitmap bmpLand, Canvas canvas, Paint paint) {
		canvas.drawBitmap(bmpLand, x*PIXEL_UNIT, y*PIXEL_UNIT+PIXEL_UNIT/2, paint);
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public List<Land> getWay() {
		return way;
	}

	public void setWay(List<Land> way) {
		this.way = way;
	}

	public boolean isHasUnit() {
		return hasUnit;
	}

	public void setHasUnit(boolean hasUnit) {
		this.hasUnit = hasUnit;
	}

	public boolean isCanMove() {
		return canMove;
	}

	public void setCanMove(boolean canMove) {
		this.canMove = canMove;
	}

	public boolean isCanBuy() {
		return canBuy;
	}

	public void setCanBuy(boolean canBuy) {
		this.canBuy = canBuy;
	}

	public Unit getUnit() {
		return unit;
	}

	public void setUnit(Unit unit) {
		this.unit = unit;
	}

	public boolean isHasSelected() {
		return hasSelected;
	}

	public void setHasSelected(boolean hasSelected) {
		this.hasSelected = hasSelected;
	}

	public boolean isHasTown() {
		return hasTown;
	}

	public void setHasTown(boolean hasTown) {
		this.hasTown = hasTown;
	}

	public Town getTown() {
		return town;
	}

	public void setTown(Town town) {
		this.town = town;
	}

	public int getLandType() {
		return landType;
	}

	public void setLandType(int landType) {
		this.landType = landType;
	}
}
