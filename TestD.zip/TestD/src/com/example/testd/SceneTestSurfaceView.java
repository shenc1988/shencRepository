package com.example.testd;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.SurfaceHolder.Callback;

/**
 * 
 * @author SC
 *
 */
public class SceneTestSurfaceView extends SurfaceView implements Callback, Runnable {

	private SurfaceHolder sfh;
	private Paint paint;
	private Thread th;
	private Canvas canvas;
	
	Bitmap landBitmap;
	Bitmap waterBitmap;
	Bitmap mountainBitmap;
	
	Bitmap battleBitmap;
	
	Bitmap confirmBitmap;
	
	Bitmap townBitmap;
	Bitmap villageBitmap;
	
	Bitmap country0Bitmap;
	Bitmap country1Bitmap;
	Bitmap country2Bitmap;
	Bitmap country3Bitmap;
	Bitmap country4Bitmap;
	Bitmap country5Bitmap;
	Bitmap country6Bitmap;
	Bitmap country7Bitmap;
	Bitmap country8Bitmap;
	Bitmap country9Bitmap;
	Bitmap country10Bitmap;
	
	Bitmap unit_1Bitmap;
	Bitmap unit_2Bitmap;
	Bitmap unit_3Bitmap;
	Bitmap unit_4Bitmap;
	Bitmap unit_5Bitmap;
	
	Bitmap unit_11Bitmap;
	Bitmap unit_12Bitmap;
	Bitmap unit_13Bitmap;
	Bitmap unit_14Bitmap;
	Bitmap unit_15Bitmap;
	
	Bitmap unit_21Bitmap;
	Bitmap unit_22Bitmap;
	Bitmap unit_23Bitmap;
	Bitmap unit_24Bitmap;
	Bitmap unit_25Bitmap;
	
	Bitmap unit_31Bitmap;
	Bitmap unit_32Bitmap;
	Bitmap unit_33Bitmap;
	Bitmap unit_34Bitmap;
	Bitmap unit_35Bitmap;
	
	Bitmap unit_41Bitmap;
	Bitmap unit_42Bitmap;
	Bitmap unit_43Bitmap;
	Bitmap unit_44Bitmap;
	Bitmap unit_45Bitmap;
	
	Bitmap unit_51Bitmap;
	Bitmap unit_52Bitmap;
	Bitmap unit_53Bitmap;
	Bitmap unit_54Bitmap;
	Bitmap unit_55Bitmap;
	
	Bitmap unit_61Bitmap;
	Bitmap unit_62Bitmap;
	Bitmap unit_63Bitmap;
	Bitmap unit_64Bitmap;
	Bitmap unit_65Bitmap;
	
	Bitmap unitSelectBitmap;
	Bitmap unitMoveBitmap;
	Bitmap unitAtkBitmap;
	
	Bitmap nextBitmap;
	Bitmap own0Bitmap;
	Bitmap own1Bitmap;
	Bitmap own2Bitmap;
	Bitmap own3Bitmap;

	Bitmap leftBitmap;
	Bitmap rightBitmap;

	Bitmap unitHasMovedBitmap;
	Bitmap unitHasActionDoneBitmap;
	Bitmap townbarrackupgradeBitmap;
	Bitmap townmarketupgradeBitmap;
	Bitmap townacademyupgradeBitmap;
	Bitmap towngovernmentupgradeBitmap;
	
//	Bitmap sp1Bitmap;

	boolean TwoVTwo = false;
	
	int aiNo = 1;
	
	boolean AIflag = false;
	boolean MoveDrawflag = false;
	boolean BattleDrawflag = false;
	private float sX = 1;
	private float sY = 1;
	private float sU = 1;
	boolean fataFlag = false;
	boolean rampleFlag = false;
	private List<Land> rampleLandwayList = new ArrayList<Land>();

	public static final int GOLD_ADD = -1;
	public static final int NO_SELECT = 0;
	public static final int SELECT_UNIT = 1;
	public static final int SELECT_TOWN = 2;
	public static int playerState = NO_SELECT;
	
	public static final int AI_GOLD_ADD = 0;
	public static final int AI_MOVE_UNIT = 1;
	public static final int AI_BUY_UNIT = 2;
	public static int aiState = AI_GOLD_ADD;
	
//	public static final int[] spAllList = {1,2,3};
//	int turnCount = 1;
	
	// ѡ�����
	boolean restartflag = true;

//	int max_x = 4;
//	int max_y = 4;

	private List<Land> landList = new ArrayList<Land>();


	private List<Integer> goldList = new ArrayList<Integer>();
//	private List<Integer> spList = new ArrayList<Integer>();
//	private List<Integer> spLevelList = new ArrayList<Integer>();
//	int nowsp = 0;

	int aiNextGoldDo = 0;
	
	private List<Integer> PLAYERLIST = new ArrayList<Integer>();
	int HARD = 0;
	int SIZE = 5;
	int MAXAI = 1;
	int PLAYER1 = 0;
	boolean BATTLEFIELD = false;
	
	
	
	int PIXEL_UNIT = 100;
	
	public SceneTestSurfaceView(Context context) {
		super(context);

		sfh = this.getHolder();
		sfh.addCallback(this);
		
		Resources res = context.getResources();
		landBitmap = BitmapFactory.decodeResource(res, R.drawable.land);
		waterBitmap = BitmapFactory.decodeResource(res, R.drawable.water);
		mountainBitmap = BitmapFactory.decodeResource(res, R.drawable.mountain);
		
		battleBitmap = BitmapFactory.decodeResource(res, R.drawable.battle);
		
		confirmBitmap = BitmapFactory.decodeResource(res, R.drawable.confirm);
		
		townBitmap = BitmapFactory.decodeResource(res, R.drawable.town);
		villageBitmap = BitmapFactory.decodeResource(res, R.drawable.village);

		country0Bitmap = BitmapFactory.decodeResource(res, R.drawable.country0);
		country1Bitmap = BitmapFactory.decodeResource(res, R.drawable.country1);
		country2Bitmap = BitmapFactory.decodeResource(res, R.drawable.country2);
		country3Bitmap = BitmapFactory.decodeResource(res, R.drawable.country3);
		country4Bitmap = BitmapFactory.decodeResource(res, R.drawable.country4);
		country5Bitmap = BitmapFactory.decodeResource(res, R.drawable.country5);
		country6Bitmap = BitmapFactory.decodeResource(res, R.drawable.country6);
		country7Bitmap = BitmapFactory.decodeResource(res, R.drawable.country7);
		country8Bitmap = BitmapFactory.decodeResource(res, R.drawable.country8);
		country9Bitmap = BitmapFactory.decodeResource(res, R.drawable.country9);
		country10Bitmap = BitmapFactory.decodeResource(res, R.drawable.country10);
		
		unit_1Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_1);
		unit_2Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_2);
		unit_3Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_3);
		unit_4Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_4);
		unit_5Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_5);

		unit_11Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_11);
		unit_12Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_12);
		unit_13Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_13);
		unit_14Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_14);
		unit_15Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_15);
		
		unit_21Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_21);
		unit_22Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_22);
		unit_23Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_23);
		unit_24Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_24);
		unit_25Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_25);
		
		unit_31Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_31);
		unit_32Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_32);
		unit_33Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_33);
		unit_34Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_34);
		unit_35Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_35);
		
		unit_41Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_41);
		unit_42Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_42);
		unit_43Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_43);
		unit_44Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_44);
		unit_45Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_45);
		
		unit_51Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_51);
		unit_52Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_52);
		unit_53Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_53);
		unit_54Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_54);
		unit_55Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_55);
			
		unit_61Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_61);
		unit_62Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_62);
		unit_63Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_63);
		unit_64Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_64);
		unit_65Bitmap = BitmapFactory.decodeResource(res, R.drawable.unit_65);
			
		unitSelectBitmap = BitmapFactory.decodeResource(res, R.drawable.unit_select);
		unitMoveBitmap = BitmapFactory.decodeResource(res, R.drawable.unit_canmove);
		unitAtkBitmap = BitmapFactory.decodeResource(res, R.drawable.unit_canatk);
		nextBitmap = BitmapFactory.decodeResource(res, R.drawable.next);
		own0Bitmap = BitmapFactory.decodeResource(res, R.drawable.own1);
		own1Bitmap = BitmapFactory.decodeResource(res, R.drawable.own2);
		own2Bitmap = BitmapFactory.decodeResource(res, R.drawable.own3);
		own3Bitmap = BitmapFactory.decodeResource(res, R.drawable.own4);
		
		leftBitmap = BitmapFactory.decodeResource(res, R.drawable.selectcountryleft);
		rightBitmap = BitmapFactory.decodeResource(res, R.drawable.selectcountryright);

		townbarrackupgradeBitmap = BitmapFactory.decodeResource(res, R.drawable.townbarrackupgrade);
		townacademyupgradeBitmap = BitmapFactory.decodeResource(res, R.drawable.townacademy);
		townmarketupgradeBitmap = BitmapFactory.decodeResource(res, R.drawable.townmarketupgrade);
		towngovernmentupgradeBitmap = BitmapFactory.decodeResource(res, R.drawable.towngovernment);
		unitHasActionDoneBitmap = BitmapFactory.decodeResource(res, R.drawable.unit_dead);
		unitHasMovedBitmap = BitmapFactory.decodeResource(res, R.drawable.unit_ismoved);
		
//		sp1Bitmap = BitmapFactory.decodeResource(res, R.drawable.sp_1);
		
		PLAYERLIST.add(0, 1);
		PLAYERLIST.add(1, 2);
		PLAYERLIST.add(2, 1);
		PLAYERLIST.add(3, 1);
		restrat(false);

		paint = new Paint();
		paint.setColor(Color.WHITE);
		setFocusable(true);
	}
	
	private Land setLandType(Land land) {
		// landtype
		int setNo = (int)(Math.random()*15);
		if (setNo==0) {
			land.setLandType(0);
			Town town = new Town(9,0,9);
			land.setHasTown(true);
			land.setTown(town);
		} else if (setNo==1) {
			land.setLandType(1);
		} else if (setNo==2) {
			land.setLandType(2);
		}
		return land;
	}
	
	private void setMap() {
		
		landList.clear();
		for (int i=0; i<SIZE; i++) {
			for (int j=0; j<SIZE; j++) {
				Land land = new Land(i, j);
				
				// ���ɵ�ͼ
				if (MAXAI == 3) {
					if ((i==0 && j==0) || (i==SIZE-1 && j==SIZE-1) || (i==1 && j==0) || (i==0 && j==1) || (i==SIZE-1 && j==SIZE-2) || (i==SIZE-2 && j==SIZE-1)
							 || (i==0 && j==SIZE-1) || (i==SIZE-1 && j==0) || (i==0 && j==SIZE-2) || (i==1 && j==SIZE-1) || (i==SIZE-2 && j==0) || (i==SIZE-1 && j==1)
							 || (i==SIZE-2 && j==SIZE-2) || (i==1 && j==1) || (i==1 && j==SIZE-2) || (i==SIZE-2 && j==1)) {
						// do nothing
					} else {
						land = setLandType(land);
					}
				} else {
					if ((i==0 && j==0) || (i==SIZE-1 && j==SIZE-1) || (i==1 && j==0) || (i==0 && j==1) || (i==SIZE-1 && j==SIZE-2) || (i==SIZE-2 && j==SIZE-1)
							|| (i==SIZE-2 && j==SIZE-2) || (i==1 && j==1)) {
						// do nothing
					} else {
						land = setLandType(land);
					}
				}

				// unit
				if (i==0 && j==0) {
					if (PLAYERLIST.get(0)==2) {
						// unit
						Unit unit1 = new Unit(0,11,0);
						land.setHasUnit(true);
						land.setUnit(unit1);
					} else if (PLAYERLIST.get(0)==3) {
						// unit
						Unit unit1 = new Unit(0,21,0);
						land.setHasUnit(true);
						land.setUnit(unit1);
					} else if (PLAYERLIST.get(0)==4) {
						// unit
						Unit unit1 = new Unit(0,31,0);
						land.setHasUnit(true);
						land.setUnit(unit1);
					} else if (PLAYERLIST.get(0)==5) {
						// unit
						Unit unit1 = new Unit(0,41,0);
						land.setHasUnit(true);
						land.setUnit(unit1);
					} else if (PLAYERLIST.get(0)==6) {
						// unit
						Unit unit1 = new Unit(0,51,0);
						land.setHasUnit(true);
						land.setUnit(unit1);
					} else if (PLAYERLIST.get(0)==7) {
						// unit
						Unit unit1 = new Unit(0,61,0);
						land.setHasUnit(true);
						land.setUnit(unit1);
					} else {
						// unit
						Unit unit1 = new Unit(0,1,0);
						land.setHasUnit(true);
						land.setUnit(unit1);
					}
					// town
					Town town1 = new Town(0,1,0);
					land.setHasTown(true);
					land.setTown(town1);
				}
				if(TwoVTwo){
					if (i==SIZE-1 && j==SIZE-1) {
						if (PLAYERLIST.get(3)==2) {
							// unit
							Unit unit4 = new Unit(3,11,0);
							unit4.setState(1);
							land.setHasUnit(true);
							land.setUnit(unit4);
						} else if (PLAYERLIST.get(3)==3) {
							// unit
							Unit unit4 = new Unit(3,21,0);
							unit4.setState(1);
							land.setHasUnit(true);
							land.setUnit(unit4);
						} else if (PLAYERLIST.get(3)==4) {
							// unit
							Unit unit4 = new Unit(3,31,0);
							unit4.setState(1);
							land.setHasUnit(true);
							land.setUnit(unit4);
						} else if (PLAYERLIST.get(3)==5) {
							// unit
							Unit unit4 = new Unit(3,41,0);
							unit4.setState(1);
							land.setHasUnit(true);
							land.setUnit(unit4);
						} else if (PLAYERLIST.get(3)==6) {
							// unit
							Unit unit4 = new Unit(3,51,0);
							unit4.setState(1);
							land.setHasUnit(true);
							land.setUnit(unit4);
						} else if (PLAYERLIST.get(3)==7) {
							// unit
							Unit unit4 = new Unit(3,61,0);
							unit4.setState(1);
							land.setHasUnit(true);
							land.setUnit(unit4);
						} else {
							// unit
							Unit unit4 = new Unit(3,1,0);
							unit4.setState(1);
							land.setHasUnit(true);
							land.setUnit(unit4);
						}
						// town
						Town town4 = new Town(3,1,0);
						land.setHasTown(true);
						land.setTown(town4);
					}
					if (MAXAI == 3){
						if (i==0 && j==SIZE-1) {
							if (PLAYERLIST.get(2)==2) {
								// unit
								Unit unit3 = new Unit(2,11,1);
								unit3.setState(1);
								land.setHasUnit(true);
								land.setUnit(unit3);
							} else if (PLAYERLIST.get(2)==3) {
								// unit
								Unit unit3 = new Unit(2,21,1);
								unit3.setState(1);
								land.setHasUnit(true);
								land.setUnit(unit3);
							} else if (PLAYERLIST.get(2)==4) {
								// unit
								Unit unit3 = new Unit(2,31,1);
								unit3.setState(1);
								land.setHasUnit(true);
								land.setUnit(unit3);
							} else if (PLAYERLIST.get(2)==5) {
								// unit
								Unit unit3 = new Unit(2,41,1);
								unit3.setState(1);
								land.setHasUnit(true);
								land.setUnit(unit3);
							} else if (PLAYERLIST.get(2)==6) {
								// unit
								Unit unit3 = new Unit(2,51,1);
								unit3.setState(1);
								land.setHasUnit(true);
								land.setUnit(unit3);
							} else if (PLAYERLIST.get(2)==7) {
								// unit
								Unit unit3 = new Unit(2,61,1);
								unit3.setState(1);
								land.setHasUnit(true);
								land.setUnit(unit3);
							} else {
								// unit
								Unit unit3 = new Unit(2,1,1);
								unit3.setState(1);
								land.setHasUnit(true);
								land.setUnit(unit3);
							}
							// town
							Town town3 = new Town(2,1,1);
							land.setHasTown(true);
							land.setTown(town3);
						}
						if (i==SIZE-1 && j==0) {
							if (PLAYERLIST.get(1)==2) {
								// unit
								Unit unit2 = new Unit(1,11,1);
								unit2.setState(1);
								land.setHasUnit(true);
								land.setUnit(unit2);
							} else if (PLAYERLIST.get(1)==3) {
								// unit
								Unit unit2 = new Unit(1,21,1);
								unit2.setState(1);
								land.setHasUnit(true);
								land.setUnit(unit2);
							} else if (PLAYERLIST.get(1)==4) {
								// unit
								Unit unit2 = new Unit(1,31,1);
								unit2.setState(1);
								land.setHasUnit(true);
								land.setUnit(unit2);
							} else if (PLAYERLIST.get(1)==5) {
								// unit
								Unit unit2 = new Unit(1,41,1);
								unit2.setState(1);
								land.setHasUnit(true);
								land.setUnit(unit2);
							} else if (PLAYERLIST.get(1)==6) {
								// unit
								Unit unit2 = new Unit(1,51,1);
								unit2.setState(1);
								land.setHasUnit(true);
								land.setUnit(unit2);
							} else if (PLAYERLIST.get(1)==7) {
								// unit
								Unit unit2 = new Unit(1,61,1);
								unit2.setState(1);
								land.setHasUnit(true);
								land.setUnit(unit2);
							} else {
								// unit
								Unit unit2 = new Unit(1,1,1);
								unit2.setState(1);
								land.setHasUnit(true);
								land.setUnit(unit2);
							}
							// town
							Town town2 = new Town(1,1,1);
							land.setHasTown(true);
							land.setTown(town2);
						}
					}
				}
				else{
					if (i==SIZE-1 && j==SIZE-1) {
						if (PLAYERLIST.get(1)==2) {
							// unit
							Unit unit2 = new Unit(1,11,1);
							unit2.setState(1);
							land.setHasUnit(true);
							land.setUnit(unit2);
						} else if (PLAYERLIST.get(1)==3) {
							// unit
							Unit unit2 = new Unit(1,21,1);
							unit2.setState(1);
							land.setHasUnit(true);
							land.setUnit(unit2);
						} else if (PLAYERLIST.get(1)==4) {
							// unit
							Unit unit2 = new Unit(1,31,1);
							unit2.setState(1);
							land.setHasUnit(true);
							land.setUnit(unit2);
						} else if (PLAYERLIST.get(1)==5) {
							// unit
							Unit unit2 = new Unit(1,41,1);
							unit2.setState(1);
							land.setHasUnit(true);
							land.setUnit(unit2);
						} else if (PLAYERLIST.get(1)==6) {
							// unit
							Unit unit2 = new Unit(1,51,1);
							unit2.setState(1);
							land.setHasUnit(true);
							land.setUnit(unit2);
						} else if (PLAYERLIST.get(1)==7) {
							// unit
							Unit unit2 = new Unit(1,61,1);
							unit2.setState(1);
							land.setHasUnit(true);
							land.setUnit(unit2);
						} else {
							// unit
							Unit unit2 = new Unit(1,1,1);
							unit2.setState(1);
							land.setHasUnit(true);
							land.setUnit(unit2);
						}
						// town
						Town town2 = new Town(1,1,1);
						land.setHasTown(true);
						land.setTown(town2);
					}
					if (MAXAI == 3){
						if (i==0 && j==SIZE-1) {
							if (PLAYERLIST.get(2)==2) {
								// unit
								Unit unit3 = new Unit(2,11,2);
								unit3.setState(1);
								land.setHasUnit(true);
								land.setUnit(unit3);
							} else if (PLAYERLIST.get(2)==3) {
								// unit
								Unit unit3 = new Unit(2,21,2);
								unit3.setState(1);
								land.setHasUnit(true);
								land.setUnit(unit3);
							} else if (PLAYERLIST.get(2)==4) {
								// unit
								Unit unit3 = new Unit(2,31,2);
								unit3.setState(1);
								land.setHasUnit(true);
								land.setUnit(unit3);
							} else if (PLAYERLIST.get(2)==5) {
								// unit
								Unit unit3 = new Unit(2,41,2);
								unit3.setState(1);
								land.setHasUnit(true);
								land.setUnit(unit3);
							} else if (PLAYERLIST.get(2)==6) {
								// unit
								Unit unit3 = new Unit(2,51,2);
								unit3.setState(1);
								land.setHasUnit(true);
								land.setUnit(unit3);
							} else if (PLAYERLIST.get(2)==7) {
								// unit
								Unit unit3 = new Unit(2,61,2);
								unit3.setState(1);
								land.setHasUnit(true);
								land.setUnit(unit3);
							} else {
								// unit
								Unit unit3 = new Unit(2,1,2);
								unit3.setState(1);
								land.setHasUnit(true);
								land.setUnit(unit3);
							}
							// town
							Town town3 = new Town(2,1,2);
							land.setHasTown(true);
							land.setTown(town3);
						}
						if (i==SIZE-1 && j==0) {
							if (PLAYERLIST.get(3)==2) {
								// unit
								Unit unit4 = new Unit(3,11,3);
								unit4.setState(1);
								land.setHasUnit(true);
								land.setUnit(unit4);
							} else if (PLAYERLIST.get(3)==3) {
								// unit
								Unit unit4 = new Unit(3,21,3);
								unit4.setState(1);
								land.setHasUnit(true);
								land.setUnit(unit4);
							} else if (PLAYERLIST.get(3)==4) {
								// unit
								Unit unit4 = new Unit(3,31,3);
								unit4.setState(1);
								land.setHasUnit(true);
								land.setUnit(unit4);
							} else if (PLAYERLIST.get(3)==5) {
								// unit
								Unit unit4 = new Unit(3,41,3);
								unit4.setState(1);
								land.setHasUnit(true);
								land.setUnit(unit4);
							} else if (PLAYERLIST.get(3)==6) {
								// unit
								Unit unit4 = new Unit(3,51,3);
								unit4.setState(1);
								land.setHasUnit(true);
								land.setUnit(unit4);
							} else if (PLAYERLIST.get(3)==7) {
								// unit
								Unit unit4 = new Unit(3,61,3);
								unit4.setState(1);
								land.setHasUnit(true);
								land.setUnit(unit4);
							} else {
								// unit
								Unit unit4 = new Unit(3,1,3);
								unit4.setState(1);
								land.setHasUnit(true);
								land.setUnit(unit4);
							}
							// town
							Town town4 = new Town(3,1,3);
							land.setHasTown(true);
							land.setTown(town4);
						}
					}
				}

				
				landList.add(land);
			}
		}
		for (int i=0; i<landList.size(); i++) {
			Land land = landList.get(i);
			int x = land.getX();
			int y = land.getY();

			List<Land> way = new ArrayList<Land>();
			
			for (int j=0; j<landList.size(); j++) {
				Land landt = landList.get(j);
				int xt = landt.getX();
				int yt = landt.getY();
				
				if (((x-1==xt)&&(y==yt)) || ((x+1==xt)&&(y==yt)) || ((y-1==yt)&&(x==xt)) || ((y+1==yt)&&(x==xt))) {
					way.add(landt);
				}
			}
			land.setWay(way);
		}
	}
	
	private void setMapBF() {
		
		landList.clear();
		for (int i=0; i<SIZE; i++) {
			for (int j=0; j<SIZE; j++) {
				Land land = new Land(i, j);
				
				//BFBFBF
				if (SIZE==9 && MAXAI==1) {
					if ((0<=i && i<=0 && 0<=j && j<=1) || (8<=i && i<=8 && 0<=j && j<=1)) {
						// unit
						int na = PLAYERLIST.get(1);
						Unit unit = new Unit(1,(na-1)*10+3,1);
						unit.setState(2);
						land.setHasUnit(true);
						land.setUnit(unit);
					}
					
					if ((1<=i && i<=2 && 0<=j && j<=0) || (6<=i && i<=7 && 0<=j && j<=0)) {
						// unit
						int na = PLAYERLIST.get(1);
						Unit unit = new Unit(1,(na-1)*10+2,1);
						unit.setState(2);
						land.setHasUnit(true);
						land.setUnit(unit);
					}
					
					if ((3<=i && i<=3 && 0<=j && j<=0) || (5<=i && i<=5 && 0<=j && j<=0)) {
						// unit
						int na = PLAYERLIST.get(1);
						Unit unit = new Unit(1,(na-1)*10+4,1);
						unit.setState(2);
						land.setHasUnit(true);
						land.setUnit(unit);
					}
					
					if ((1<=i && i<=7 && 1<=j && j<=1)) {
						// unit
						int na = PLAYERLIST.get(1);
						Unit unit = new Unit(1,(na-1)*10+1,1);
						unit.setState(2);
						land.setHasUnit(true);
						land.setUnit(unit);
					}
					
					if ((4<=i && i<=4 && 0<=j && j<=0)) {
						// unit
						int na = PLAYERLIST.get(1);
						Unit unit = new Unit(1,(na-1)*10+5,1);
						unit.setState(2);
						land.setHasUnit(true);
						land.setUnit(unit);
					}
					
					if ((0<=i && i<=0 && 7<=j && j<=8) || (8<=i && i<=8 && 7<=j && j<=8)) {
						// unit
						int na = PLAYERLIST.get(0);
						Unit unit = new Unit(0,(na-1)*10+3,0);
						unit.setState(2);
						land.setHasUnit(true);
						land.setUnit(unit);
					}
					
					if ((1<=i && i<=2 && 8<=j && j<=8) || (6<=i && i<=7 && 8<=j && j<=8)) {
						// unit
						int na = PLAYERLIST.get(0);
						Unit unit = new Unit(0,(na-1)*10+2,0);
						unit.setState(2);
						land.setHasUnit(true);
						land.setUnit(unit);
					}
					
					if ((3<=i && i<=3 && 8<=j && j<=8) || (5<=i && i<=5 && 8<=j && j<=8)) {
						// unit
						int na = PLAYERLIST.get(0);
						Unit unit = new Unit(0,(na-1)*10+4,0);
						unit.setState(2);
						land.setHasUnit(true);
						land.setUnit(unit);
					}
					
					if ((1<=i && i<=7 && 7<=j && j<=7)) {
						// unit
						int na = PLAYERLIST.get(0);
						Unit unit = new Unit(0,(na-1)*10+1,0);
						unit.setState(2);
						land.setHasUnit(true);
						land.setUnit(unit);
					}
					
					if ((4<=i && i<=4 &&  8<=j && j<=8)) {
						// unit
						int na = PLAYERLIST.get(0);
						Unit unit = new Unit(0,(na-1)*10+5,0);
						unit.setState(2);
						land.setHasUnit(true);
						land.setUnit(unit);
					}
				}
				
				landList.add(land);
			}
		}
		for (int i=0; i<landList.size(); i++) {
			Land land = landList.get(i);
			int x = land.getX();
			int y = land.getY();

			List<Land> way = new ArrayList<Land>();
			
			for (int j=0; j<landList.size(); j++) {
				Land landt = landList.get(j);
				int xt = landt.getX();
				int yt = landt.getY();
				
				if (((x-1==xt)&&(y==yt)) || ((x+1==xt)&&(y==yt)) || ((y-1==yt)&&(x==xt)) || ((y+1==yt)&&(x==xt))) {
					way.add(landt);
				}
			}
			land.setWay(way);
		}
	}
	
	private void restrat(boolean load) {
		
		if (load){
			openGame();
			
			// unit
			PLAYERLIST.clear();
			if (PLAYER1 == 0){
				PLAYER1 = (int)(Math.random()*7+1);
			}
			PLAYERLIST.add(0, PLAYER1);
			PLAYERLIST.add(1, (int)(Math.random()*7+1));
			PLAYERLIST.add(2, (int)(Math.random()*7+1));
			PLAYERLIST.add(3, (int)(Math.random()*7+1));
			
			goldList.clear();
			goldList.add(0, 5);
			goldList.add(1, 5);

			//MAXAI
			goldList.add(2, 5);
			goldList.add(3, 5);
		}
		else{
			// unit
			PLAYERLIST.clear();
			if (PLAYER1 == 0){
				PLAYER1 = (int)(Math.random()*7+1);
			}
			PLAYERLIST.add(0, PLAYER1);
			PLAYERLIST.add(1, (int)(Math.random()*7+1));
			PLAYERLIST.add(2, (int)(Math.random()*7+1));
			PLAYERLIST.add(3, (int)(Math.random()*7+1));

			if (BATTLEFIELD) {
				setMapBF();
			} else {
				setMap();
			}

			goldList.clear();
			goldList.add(0, 5);
			goldList.add(1, 5);

			//MAXAI
			goldList.add(2, 5);
			goldList.add(3, 5);

		}
//		spList.clear();
//		spList.add(0, 0);
//		spList.add(1, 0);
//		
//		spLevelList.clear();
//		spLevelList.add(0, 1);
//		spLevelList.add(1, 1);
	}


	@Override
	public void surfaceCreated(SurfaceHolder holder) {

		th = new Thread(this);
		th.start();
	}


	public void myDraw() {
		try {
			canvas = sfh.lockCanvas();
			if (canvas != null) {
				canvas.drawRGB(0, 0, 0);
				
				int own0total = 0;
				int own1total = 0;
				
				for (int i = 0; i < landList.size(); i++)
				{
					Land land = landList.get(i);
					if (land.getLandType()==1) {
						land.draw(waterBitmap, canvas, paint);
					} else if (land.getLandType()==2) {
						land.draw(mountainBitmap, canvas, paint);
					} else {
						land.draw(landBitmap, canvas, paint);
					}
					if (land.isHasTown()) {
						Town town = land.getTown();
						if (town.getType()==1) {
							land.draw(townBitmap, canvas, paint);
						} else {
							land.draw(villageBitmap, canvas, paint);
						}
						
						if (town.getOwner()==0) {
							land.drawOwnFlag(own0Bitmap, canvas, paint);
						} else if (town.getOwner()==1) {
							land.drawOwnFlag(own1Bitmap, canvas, paint);
						} else if (town.getOwner()==2) {
							land.drawOwnFlag(own2Bitmap, canvas, paint);
						} else if (town.getOwner()==3) {
							land.drawOwnFlag(own3Bitmap, canvas, paint);
						}
						
						if (town.getCamp()==0) {
							own0total++;
						} else {
							own1total++;
						}
					}
					if (land.isHasUnit()) {
						Unit unit = land.getUnit();
						
						if (unit.getCamp()==0) {
							own0total++;
						} else {
							own1total++;
						}
						
						if (MoveDrawflag && land.isHasSelected()) {
							
						} else {
							// unit
							if (unit.getType()==1) {
								land.draw(unit_1Bitmap, canvas, paint);
							} else if (unit.getType()==2) {
								land.draw(unit_2Bitmap, canvas, paint);
							} else if (unit.getType()==3) {
								land.draw(unit_3Bitmap, canvas, paint);
							} else if (unit.getType()==4) {
								land.draw(unit_4Bitmap, canvas, paint);
							} else if (unit.getType()==5) {
								land.draw(unit_5Bitmap, canvas, paint);
							} else if (unit.getType()==11) {
								land.draw(unit_11Bitmap, canvas, paint);
							} else if (unit.getType()==12) {
								land.draw(unit_12Bitmap, canvas, paint);
							} else if (unit.getType()==13) {
								land.draw(unit_13Bitmap, canvas, paint);
							} else if (unit.getType()==14) {
								land.draw(unit_14Bitmap, canvas, paint);
							} else if (unit.getType()==15) {
								land.draw(unit_15Bitmap, canvas, paint);
							} else if (unit.getType()==21) {
								land.draw(unit_21Bitmap, canvas, paint);
							} else if (unit.getType()==22) {
								land.draw(unit_22Bitmap, canvas, paint);
							} else if (unit.getType()==23) {
								land.draw(unit_23Bitmap, canvas, paint);
							} else if (unit.getType()==24) {
								land.draw(unit_24Bitmap, canvas, paint);
							} else if (unit.getType()==25) {
								land.draw(unit_25Bitmap, canvas, paint);
							} else if (unit.getType()==31) {
								land.draw(unit_31Bitmap, canvas, paint);
							} else if (unit.getType()==32) {
								land.draw(unit_32Bitmap, canvas, paint);
							} else if (unit.getType()==33) {
								land.draw(unit_33Bitmap, canvas, paint);
							} else if (unit.getType()==34) {
								land.draw(unit_34Bitmap, canvas, paint);
							} else if (unit.getType()==35) {
								land.draw(unit_35Bitmap, canvas, paint);
							} else if (unit.getType()==41) {
								land.draw(unit_41Bitmap, canvas, paint);
							} else if (unit.getType()==42) {
								land.draw(unit_42Bitmap, canvas, paint);
							} else if (unit.getType()==43) {
								land.draw(unit_43Bitmap, canvas, paint);
							} else if (unit.getType()==44) {
								land.draw(unit_44Bitmap, canvas, paint);
							} else if (unit.getType()==45) {
								land.draw(unit_45Bitmap, canvas, paint);
							} else if (unit.getType()==51) {
								land.draw(unit_51Bitmap, canvas, paint);
							} else if (unit.getType()==52) {
								land.draw(unit_52Bitmap, canvas, paint);
							} else if (unit.getType()==53) {
								land.draw(unit_53Bitmap, canvas, paint);
							} else if (unit.getType()==54) {
								land.draw(unit_54Bitmap, canvas, paint);
							} else if (unit.getType()==55) {
								land.draw(unit_55Bitmap, canvas, paint);
							} else if (unit.getType()==61) {
								land.draw(unit_61Bitmap, canvas, paint);
							} else if (unit.getType()==62) {
								land.draw(unit_62Bitmap, canvas, paint);
							} else if (unit.getType()==63) {
								land.draw(unit_63Bitmap, canvas, paint);
							} else if (unit.getType()==64) {
								land.draw(unit_64Bitmap, canvas, paint);
							} else if (unit.getType()==65) {
								land.draw(unit_65Bitmap, canvas, paint);
							} else {
								land.draw(unit_1Bitmap, canvas, paint);
							}

							if (unit.getOwner()==0) {
								land.drawOwnFlag(own0Bitmap, canvas, paint);
							} else if (unit.getOwner()==1) {
								land.drawOwnFlag(own1Bitmap, canvas, paint);
							} else if (unit.getOwner()==2) {
								land.drawOwnFlag(own2Bitmap, canvas, paint);
							} else if (unit.getOwner()==3) {
								land.drawOwnFlag(own3Bitmap, canvas, paint);
							}
							
							if (unit.isAttackedflag()) {
								land.draw(unitHasActionDoneBitmap, canvas, paint);
							} else if (unit.isMovedflag()) {
								land.draw(unitHasMovedBitmap, canvas, paint);
							}
							
							paint.setColor(Color.RED);
							canvas.drawRect(land.getX()*PIXEL_UNIT, land.getY()*PIXEL_UNIT+PIXEL_UNIT-5, land.getX()*PIXEL_UNIT+PIXEL_UNIT, land.getY()*PIXEL_UNIT+PIXEL_UNIT, paint);
							paint.setColor(Color.GREEN);
							float c = PIXEL_UNIT-PIXEL_UNIT*(((float)unit.getMaxlife()-(float)unit.getLife())/(float)unit.getMaxlife());
							canvas.drawRect(land.getX()*PIXEL_UNIT, land.getY()*PIXEL_UNIT+PIXEL_UNIT-5, land.getX()*PIXEL_UNIT+c, land.getY()*PIXEL_UNIT+PIXEL_UNIT, paint);
							paint.setColor(Color.WHITE);
							
						}

					}
					
					if (land.isCanMove()) {
						
						if (MoveDrawflag || BattleDrawflag) {
							
						} else {

							if (land.isHasUnit() && land.getUnit().getCamp()!=0){
								land.drawMoveFlag(unitAtkBitmap, canvas, paint);
							} else if (land.isHasUnit() && land.getUnit().getCamp()==0 ){
								//land.drawMoveFlag(unitAtkBitmap, canvas, paint);
							} else {
								land.drawMoveFlag(unitMoveBitmap, canvas, paint);
							}
							
						}
					}
					
					if (land.isHasSelected()) {
						
						if (MoveDrawflag || BattleDrawflag) {
							
						} else {
							
							land.draw(unitSelectBitmap, canvas, paint);
							
						}
						
						//
						//paint.setColor(Color.BLACK);
						//canvas.drawRect(0, 575, 500, 700, paint);
						paint.setColor(Color.WHITE);
						//

						if (land.isHasSelected() && land.isHasTown() && land.getTown().getOwner()==0) {
							List<Integer> state = land.getTown().getTownState();
							for (int j = 0; j < state.size(); j++)
							{
								// unit
								if (state.get(j) == 81) {
									canvas.drawBitmap(townbarrackupgradeBitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
									canvas.drawText("cost 5", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									canvas.drawText("level 1", j*PIXEL_UNIT, 13*PIXEL_UNIT+20, paint);
								} else if (state.get(j) == 82) {
									canvas.drawBitmap(townacademyupgradeBitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
									canvas.drawText("cost 10", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									canvas.drawText("level 2", j*PIXEL_UNIT, 13*PIXEL_UNIT+20, paint);
								} else if (state.get(j) == 83) {
									canvas.drawText("level 3", j*PIXEL_UNIT, 13*PIXEL_UNIT+20, paint);
								} else if (state.get(j) == 84) {
									canvas.drawBitmap(townmarketupgradeBitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
									canvas.drawText("cost 10", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									canvas.drawText("turn+" + land.getTown().getTurnGoldUp(), j*PIXEL_UNIT, 13*PIXEL_UNIT+20, paint);
								} else if (state.get(j) == 85) {
									canvas.drawBitmap(towngovernmentupgradeBitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
									canvas.drawText("cost 15", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									canvas.drawText("turn +" + land.getTown().getTurnGoldUp(), j*PIXEL_UNIT, 13*PIXEL_UNIT+20, paint);
								} else if (state.get(j) == 86) {
									canvas.drawText("turn +" + land.getTown().getTurnGoldUp(), j*PIXEL_UNIT, 13*PIXEL_UNIT+20, paint);
								}
							}
						}
					}

				}

				if (playerState == 1) {

				}
				
				if (playerState == 2) {
					for (int i = 0; i < landList.size(); i++)
					{
						Land land = landList.get(i);
						if (land.isHasSelected() && land.isHasTown() && land.getTown().getOwner()==0) {
							List<Integer> state = land.getTown().getTownState();
							for (int j = 0; j < state.size(); j++)
							{
								if (PLAYERLIST.get(0)==2) {
									// unit
									if (state.get(j) == 1) {
										canvas.drawBitmap(unit_11Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 10", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									} else if (state.get(j) == 2) {
										canvas.drawBitmap(unit_12Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 10", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									} else if (state.get(j) == 3) {
										canvas.drawBitmap(unit_13Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 10", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									} else if (state.get(j) == 4) {
										canvas.drawBitmap(unit_14Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 16", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									} else if (state.get(j) == 5) {
										canvas.drawBitmap(unit_15Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 16", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									}
								} else if (PLAYERLIST.get(0)==3) {
									// unit
									if (state.get(j) == 1) {
										canvas.drawBitmap(unit_21Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 10", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									} else if (state.get(j) == 2) {
										canvas.drawBitmap(unit_22Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 10", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									} else if (state.get(j) == 3) {
										canvas.drawBitmap(unit_23Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 13", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									} else if (state.get(j) == 4) {
										canvas.drawBitmap(unit_24Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 12", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									} else if (state.get(j) == 5) {
										canvas.drawBitmap(unit_25Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 14", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									}
								} else if (PLAYERLIST.get(0)==4) {
									// unit
									if (state.get(j) == 1) {
										canvas.drawBitmap(unit_31Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 10", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									} else if (state.get(j) == 2) {
										canvas.drawBitmap(unit_32Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 10", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									} else if (state.get(j) == 3) {
										canvas.drawBitmap(unit_33Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 15", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									} else if (state.get(j) == 4) {
										canvas.drawBitmap(unit_34Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 12", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									} else if (state.get(j) == 5) {
										canvas.drawBitmap(unit_35Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 17", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									}
								} else if (PLAYERLIST.get(0)==5) {
									// unit
									if (state.get(j) == 1) {
										canvas.drawBitmap(unit_41Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 10", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									} else if (state.get(j) == 2) {
										canvas.drawBitmap(unit_42Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 10", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									} else if (state.get(j) == 3) {
										canvas.drawBitmap(unit_43Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 15", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									} else if (state.get(j) == 4) {
										canvas.drawBitmap(unit_44Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 13", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									} else if (state.get(j) == 5) {
										canvas.drawBitmap(unit_45Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 17", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									}
								} else if (PLAYERLIST.get(0)==6) {
									// unit
									if (state.get(j) == 1) {
										canvas.drawBitmap(unit_51Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 10", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									} else if (state.get(j) == 2) {
										canvas.drawBitmap(unit_52Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 10", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									} else if (state.get(j) == 3) {
										canvas.drawBitmap(unit_53Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 15", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									} else if (state.get(j) == 4) {
										canvas.drawBitmap(unit_54Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 13", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									} else if (state.get(j) == 5) {
										canvas.drawBitmap(unit_55Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 17", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									}
								} else if (PLAYERLIST.get(0)==7) {
									// unit
									if (state.get(j) == 1) {
										canvas.drawBitmap(unit_61Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 10", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									} else if (state.get(j) == 2) {
										canvas.drawBitmap(unit_62Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 10", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									} else if (state.get(j) == 3) {
										canvas.drawBitmap(unit_63Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 15", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									} else if (state.get(j) == 4) {
										canvas.drawBitmap(unit_64Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 13", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									} else if (state.get(j) == 5) {
										canvas.drawBitmap(unit_65Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 18", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									}
								} else {
									// unit
									if (state.get(j) == 1) {
										canvas.drawBitmap(unit_1Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 10", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									} else if (state.get(j) == 2) {
										canvas.drawBitmap(unit_2Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 10", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									} else if (state.get(j) == 3) {
										canvas.drawBitmap(unit_3Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 15", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									} else if (state.get(j) == 4) {
										canvas.drawBitmap(unit_4Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 13", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									} else if (state.get(j) == 5) {
										canvas.drawBitmap(unit_5Bitmap, j*PIXEL_UNIT, 12*PIXEL_UNIT, paint);
										canvas.drawText("cost 17", j*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
									}
								}

							}
						}
					}
				}

				canvas.drawText("G:" + goldList.get(0), 8*PIXEL_UNIT, 13*PIXEL_UNIT+10, paint);
				canvas.drawText("G:" + goldList.get(1), 8*PIXEL_UNIT, 13*PIXEL_UNIT+20, paint);
				if (MAXAI==3){
					canvas.drawText("G:" + goldList.get(2), 8*PIXEL_UNIT+40, 13*PIXEL_UNIT+10, paint);
					canvas.drawText("G:" + goldList.get(3), 8*PIXEL_UNIT+40, 13*PIXEL_UNIT+20, paint);
				}
//				canvas.drawText("P:" + spList.get(0), 440, 13*PIXEL_UNIT+10, paint);
//				canvas.drawText("P:" + spList.get(1), 440, 13*PIXEL_UNIT+20, paint);
				canvas.drawBitmap(nextBitmap, 8*PIXEL_UNIT, 12*PIXEL_UNIT, paint);

				//canvas.drawBitmap(nextBitmap, 7*PIXEL_UNIT, 12*PIXEL_UNIT, paint);//save
				canvas.drawBitmap(nextBitmap, 9*PIXEL_UNIT, 12*PIXEL_UNIT, paint);//save
				// SP
//				canvas.drawBitmap(sp1Bitmap, 0, 525, paint);
				
				if (own1total == 0) {
					canvas.drawText("you win", 0, 13*PIXEL_UNIT+20, paint);
					restartflag = true;
				} else if (own0total == 0) {
					canvas.drawText("you lose", 0, 13*PIXEL_UNIT+20, paint);
					restartflag = true;
				}
				
				if (restartflag) {
					paint.setColor(Color.DKGRAY);
					canvas.drawRect(2*PIXEL_UNIT, 3*PIXEL_UNIT, 8*PIXEL_UNIT, 10*PIXEL_UNIT, paint);
					paint.setColor(Color.WHITE);
					canvas.drawBitmap(nextBitmap, 4*PIXEL_UNIT, 3*PIXEL_UNIT, paint);
					canvas.drawBitmap(nextBitmap, 5*PIXEL_UNIT, 3*PIXEL_UNIT, paint);
					canvas.drawText("Difficulty:", 2*PIXEL_UNIT, 4*PIXEL_UNIT, paint);
					canvas.drawBitmap(nextBitmap, 4*PIXEL_UNIT, 4*PIXEL_UNIT, paint);
					canvas.drawBitmap(nextBitmap, 5*PIXEL_UNIT, 4*PIXEL_UNIT, paint);
					canvas.drawBitmap(nextBitmap, 6*PIXEL_UNIT, 4*PIXEL_UNIT, paint);
					canvas.drawText("AINumber:", 2*PIXEL_UNIT, 5*PIXEL_UNIT, paint);
					canvas.drawBitmap(nextBitmap, 4*PIXEL_UNIT, 5*PIXEL_UNIT, paint);
					canvas.drawBitmap(nextBitmap, 5*PIXEL_UNIT, 5*PIXEL_UNIT, paint);
					canvas.drawBitmap(nextBitmap, 6*PIXEL_UNIT, 5*PIXEL_UNIT, paint);
					canvas.drawText("MapSize:", 2*PIXEL_UNIT, 6*PIXEL_UNIT, paint);
					canvas.drawBitmap(nextBitmap, 3*PIXEL_UNIT, 6*PIXEL_UNIT, paint);
					canvas.drawBitmap(nextBitmap, 4*PIXEL_UNIT, 6*PIXEL_UNIT, paint);
					canvas.drawBitmap(nextBitmap, 5*PIXEL_UNIT, 6*PIXEL_UNIT, paint);
					canvas.drawBitmap(nextBitmap, 6*PIXEL_UNIT, 6*PIXEL_UNIT, paint);
					canvas.drawText("Nation:", 2*PIXEL_UNIT, 7*PIXEL_UNIT, paint);
					canvas.drawBitmap(leftBitmap, 2*PIXEL_UNIT, 7*PIXEL_UNIT, paint);
//					canvas.drawBitmap(nextBitmap, 3*PIXEL_UNIT, 7*PIXEL_UNIT, paint);
					canvas.drawBitmap(rightBitmap, 4*PIXEL_UNIT, 7*PIXEL_UNIT, paint);
//					canvas.drawBitmap(nextBitmap, 5*PIXEL_UNIT, 7*PIXEL_UNIT, paint);
//					canvas.drawBitmap(nextBitmap, 6*PIXEL_UNIT, 7*PIXEL_UNIT, paint);
					// unit
//					canvas.drawBitmap(nextBitmap, 2*PIXEL_UNIT, 8*PIXEL_UNIT, paint);
//					canvas.drawBitmap(nextBitmap, 3*PIXEL_UNIT, 8*PIXEL_UNIT, paint);
					canvas.drawBitmap(confirmBitmap, 5*PIXEL_UNIT, 9*PIXEL_UNIT, paint);
					canvas.drawBitmap(nextBitmap, 6*PIXEL_UNIT, 9*PIXEL_UNIT, paint);//save
					if (!BATTLEFIELD) {
						canvas.drawBitmap(unitSelectBitmap, 4*PIXEL_UNIT, 3*PIXEL_UNIT, paint);
					} else {
						canvas.drawBitmap(unitSelectBitmap, 5*PIXEL_UNIT, 3*PIXEL_UNIT, paint);
					}
					if (HARD==0) {
						canvas.drawBitmap(unitSelectBitmap, 4*PIXEL_UNIT, 4*PIXEL_UNIT, paint);
					} else if(HARD==2) {
						canvas.drawBitmap(unitSelectBitmap, 5*PIXEL_UNIT, 4*PIXEL_UNIT, paint);
					} else {
						canvas.drawBitmap(unitSelectBitmap, 6*PIXEL_UNIT, 4*PIXEL_UNIT, paint);
					}
					if (MAXAI==1) {
						canvas.drawBitmap(unitSelectBitmap, 4*PIXEL_UNIT, 5*PIXEL_UNIT, paint);
					} else if (TwoVTwo) {
						canvas.drawBitmap(unitSelectBitmap, 6*PIXEL_UNIT, 5*PIXEL_UNIT, paint);
					}else{
						canvas.drawBitmap(unitSelectBitmap, 5*PIXEL_UNIT, 5*PIXEL_UNIT, paint);
						
					}
					if (SIZE==5) {
						canvas.drawBitmap(unitSelectBitmap, 3*PIXEL_UNIT, 6*PIXEL_UNIT, paint);
					} else if (SIZE==7) {
						canvas.drawBitmap(unitSelectBitmap, 4*PIXEL_UNIT, 6*PIXEL_UNIT, paint);
					} else if (SIZE==9) {
						canvas.drawBitmap(unitSelectBitmap, 5*PIXEL_UNIT, 6*PIXEL_UNIT, paint);
					} else {
						canvas.drawBitmap(unitSelectBitmap, 6*PIXEL_UNIT, 6*PIXEL_UNIT, paint);
					}
					if (PLAYER1==1) {
						canvas.drawBitmap(country1Bitmap, 3*PIXEL_UNIT, 7*PIXEL_UNIT, paint);
					} else if (PLAYER1==2) {
						canvas.drawBitmap(country2Bitmap, 3*PIXEL_UNIT, 7*PIXEL_UNIT, paint);
					} else if (PLAYER1==3) {
						canvas.drawBitmap(country3Bitmap, 3*PIXEL_UNIT, 7*PIXEL_UNIT, paint);
					} else if (PLAYER1==4) {
						canvas.drawBitmap(country4Bitmap, 3*PIXEL_UNIT, 7*PIXEL_UNIT, paint);
					} else if (PLAYER1==5) {
						canvas.drawBitmap(country5Bitmap, 3*PIXEL_UNIT, 7*PIXEL_UNIT, paint);
					} else if (PLAYER1==6) {
						canvas.drawBitmap(country6Bitmap, 3*PIXEL_UNIT, 7*PIXEL_UNIT, paint);
					} else if (PLAYER1==7) {
						canvas.drawBitmap(country7Bitmap, 3*PIXEL_UNIT, 7*PIXEL_UNIT, paint);
					} else {
						canvas.drawBitmap(country0Bitmap, 3*PIXEL_UNIT, 7*PIXEL_UNIT, paint);
					}
				}
				
				if (MoveDrawflag) {
					// unit
					if (sU==1) {
						canvas.drawBitmap(unit_1Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==2) {
						canvas.drawBitmap(unit_2Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==3) {
						canvas.drawBitmap(unit_3Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==4) {
						canvas.drawBitmap(unit_4Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==5) {
						canvas.drawBitmap(unit_5Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==11) {
						canvas.drawBitmap(unit_11Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==12) {
						canvas.drawBitmap(unit_12Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==13) {
						canvas.drawBitmap(unit_13Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==14) {
						canvas.drawBitmap(unit_14Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==15) {
						canvas.drawBitmap(unit_15Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==21) {
						canvas.drawBitmap(unit_21Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==22) {
						canvas.drawBitmap(unit_22Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==23) {
						canvas.drawBitmap(unit_23Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==24) {
						canvas.drawBitmap(unit_24Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==25) {
						canvas.drawBitmap(unit_25Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==31) {
						canvas.drawBitmap(unit_31Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==32) {
						canvas.drawBitmap(unit_32Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==33) {
						canvas.drawBitmap(unit_33Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==34) {
						canvas.drawBitmap(unit_34Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==35) {
						canvas.drawBitmap(unit_35Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==41) {
						canvas.drawBitmap(unit_41Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==42) {
						canvas.drawBitmap(unit_42Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==43) {
						canvas.drawBitmap(unit_43Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==44) {
						canvas.drawBitmap(unit_44Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==45) {
						canvas.drawBitmap(unit_45Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==51) {
						// unit
						canvas.drawBitmap(unit_51Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==52) {
						canvas.drawBitmap(unit_52Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==53) {
						canvas.drawBitmap(unit_53Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==54) {
						canvas.drawBitmap(unit_54Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==55) {
						canvas.drawBitmap(unit_55Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==61) {
						// unit
						canvas.drawBitmap(unit_61Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==62) {
						canvas.drawBitmap(unit_62Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==63) {
						canvas.drawBitmap(unit_63Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==64) {
						canvas.drawBitmap(unit_64Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else if (sU==65) {
						canvas.drawBitmap(unit_65Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					} else {
						canvas.drawBitmap(unit_1Bitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					}
				}
				
				if (BattleDrawflag) {
					canvas.drawBitmap(battleBitmap, sX*PIXEL_UNIT, sY*PIXEL_UNIT, paint);
					paint.setColor(Color.RED);
					paint.setTypeface(Typeface.DEFAULT_BOLD);
					if (fataFlag) {
						canvas.drawText("   "+(int)sU+"!", sX*PIXEL_UNIT, sY*PIXEL_UNIT+10, paint);
					} else {
						canvas.drawText("   "+(int)sU, sX*PIXEL_UNIT, sY*PIXEL_UNIT+10, paint);
					}
					if (rampleFlag) {
						if (rampleLandwayList.size()>0) {
							int size = rampleLandwayList.size();
							for (int i = 0; i < size; i++)
							{
								if (rampleLandwayList.get(i).isHasUnit()) {
									canvas.drawBitmap(battleBitmap, rampleLandwayList.get(i).getX()*PIXEL_UNIT,
											rampleLandwayList.get(i).getY()*PIXEL_UNIT, paint);
									canvas.drawText("   "+1, rampleLandwayList.get(i).getX()*PIXEL_UNIT,
											rampleLandwayList.get(i).getY()*PIXEL_UNIT+10, paint);
								}
								
							}
						}
					}
					paint.setTypeface(Typeface.DEFAULT);
					paint.setColor(Color.WHITE);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (canvas != null)
				sfh.unlockCanvasAndPost(canvas);
		}
	}

	// ѡ��ص�
	private void playerState0Action(int touchx,int touchy){

		playerState = 0;
		
		for (int i = 0; i < landList.size(); i++)
		{
			Land land = landList.get(i);
			int x = land.getX();
			int y = land.getY();
			if (((x)*PIXEL_UNIT < touchx && touchx < ((x)*PIXEL_UNIT+PIXEL_UNIT)) && ((y)*PIXEL_UNIT < touchy && touchy < ((y)*PIXEL_UNIT+PIXEL_UNIT))){
				for (int j = 0; j < landList.size(); j++)
				{
					Land landsel = landList.get(j);
					landsel.setHasSelected(false);
				}
				land.setHasSelected(true);
			}
		}

		for (int i = 0; i < landList.size(); i++)
		{
			Land land = landList.get(i);
			
			if (land.isHasSelected()) {

				// �м�����λ
				if (land.isHasUnit() && land.getUnit().getOwner()==0) {
					Unit unit = land.getUnit();

					// δ�ƶ�
					if (!unit.isMovedflag()) {
						
						// ���ƶ��ص�
						moveRangeSet(land);
						// �ɹ����ص�
						atkRangeSet(land);
						// ��λ���ڵص㲻����Ϊ�ƶ�Ŀ�ĵ�
						land.setCanMove(false);
						
						// δ����
					} else if (!unit.isAttackedflag()) {
						// �ɹ����ص�
						atkRangeSet(land);
						land.setCanMove(false);
					}

					// ��λѡ��״̬
					playerState = 1;
				} else if (!land.isHasUnit() && land.isHasTown() && land.getTown().getOwner()==0) {
					// �������״̬
					playerState = 2;
				}
			}
		}
	}
	
	private int range(Land landFrom, Land landTo) {
		List<Land> landwayList = new ArrayList<Land>();
		landwayList.add(landFrom);
		int range = 0;
		while (!landwayList.contains(landTo)) {
			int size = landwayList.size();
			range++;
			for (int j = 0; j < size; j++)
			{
				Land landway = landwayList.get(j);
				List<Land> way = landway.getWay();
				for (int n = 0; n < way.size(); n++)
				{
					Land landwayto = way.get(n);
					if (!landwayList.contains(landwayto)) {
						landwayList.add(landwayto);
					}
				}
			}
		}
		return range;
	}
	
	private List<Land> moveRangeSet(Land land) {
		List<Land> landwayList = new ArrayList<Land>();
		landwayList.add(land);
		int own = land.getUnit().getOwner();
		//add
		int camp = land.getUnit().getCamp();
		
		
		int movement = land.getUnit().getMovement();
		for (int m = 1; m <= movement; m++)
		{
			int size = landwayList.size();
			for (int j = 0; j < size; j++)
			{
				Land landway = landwayList.get(j);
				List<Land> way = landway.getWay();
				for (int n = 0; n < way.size(); n++)
				{
					Land landwayto = way.get(n);
					// TODO
					if (landwayto.getLandType()==0) {
						if ((!landwayto.isHasUnit()) || (landwayto.isHasUnit() && landwayto.getUnit().getOwner()==own) || (landwayto.isHasUnit() && landwayto.getUnit().getCamp()==camp)) {
							if (!landwayList.contains(landwayto)) {
								landwayto.setCanMove(true);
								landwayList.add(landwayto);
							}
						}
					}

				}
			}
			
		}
		for (int n = 0; n < landwayList.size(); n++)
		{
			Land landway = landwayList.get(n);
			if (landway.isHasUnit()) {
				landway.setCanMove(false);
			}
		}
		return landwayList;
	}
	
	private List<Land> atkmoveRangeSet(Land land,List<Land> landwayList){
		int attackrange = land.getUnit().getAttackrange();
		//int own = land.getUnit().getOwner();
		//add
		int camp = land.getUnit().getCamp();
		
		List<Land> alllandatkwayList = new ArrayList<Land>();
		for (int n = 0; n < landwayList.size(); n++)
		{
			Land landway = landwayList.get(n);
			if (landway.isCanMove()) {
				List<Land> landatkwayList = new ArrayList<Land>();
				landatkwayList.add(landway);
				for (int m = 1; m <= attackrange; m++)
				{
					int size = landatkwayList.size();
					for (int j = 0; j < size; j++)
					{
						Land landatkway = landatkwayList.get(j);
						List<Land> way = landatkway.getWay();
						for (int k = 0; k < way.size(); k++)
						{
							Land landatkwayto = way.get(k);
							// TODO
							if (landatkwayto.getLandType()!=2) {
								if (!landatkwayList.contains(landatkwayto)) {
									landatkwayList.add(landatkwayto);
								}
								if (landatkwayto.isHasUnit() && landatkwayto.getUnit().getCamp()!=camp) {
									if (!alllandatkwayList.contains(landatkwayto)) {
										alllandatkwayList.add(landatkwayto);
									}
								}
							}
						}
					}
				}
			}
		}
		return alllandatkwayList;
	}
	
	private List<Land> atkRangeSet(Land land) {
		List<Land> landatkList = new ArrayList<Land>();
		landatkList.add(land);
		int own = land.getUnit().getOwner();
		//add
		int camp = land.getUnit().getCamp();
		int attackrange = land.getUnit().getAttackrange();
		for (int m = 1; m <= attackrange; m++)
		{
			int size = landatkList.size();
			for (int j = 0; j < size; j++)
			{
				Land landatk = landatkList.get(j);
				List<Land> way = landatk.getWay();
				for (int n = 0; n < way.size(); n++)
				{
					Land landatkto = way.get(n);
					// TODO
					if (landatkto.getLandType()!=2) {
						if (!landatkList.contains(landatkto)) {
							landatkList.add(landatkto);
						}
					}
				}
			}
		}
		List<Land> landcanatkList = new ArrayList<Land>();
		for (int n = 0; n < landatkList.size(); n++)
		{
			Land landatk = landatkList.get(n);
			if (landatk.isHasUnit() && landatk.getUnit().getOwner()!=own && landatk.getUnit().getCamp()!= camp) {
				if (AIflag){
					landcanatkList.add(landatk);
				} else {
					landatk.setCanMove(true);
				}
			}
		}
		return landcanatkList;
	}
	
	private void battle(Land landAtk, Land landDef) {
		Unit unitatk = landAtk.getUnit();
		Unit unitdef = landDef.getUnit();
		
		BattleDrawflag = true;
		int range = range(landAtk, landDef);
		
		//�������б�ǹ����
		if (unitatk.isJavelinAtk()) {
			if (range <= 1) {
				int life = unitdef.getLife()-1;
				if (life < 0) {
					life = 0;
				}
				unitdef.setLife(life);
				sX = landDef.getX();
				sY = landDef.getY();
				sU = 1;
				myDraw();
				try {
					Thread.sleep(250);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				if (unitdef.getLife()<=0) {
					landDef.setUnit(null);
					landDef.setHasUnit(false);
					
					BattleDrawflag = false;
					
					unitatk.setAttackedflag(true);
					unitatk.setMovedflag(true);
					
					return;
				}
			}
		}
		
//		if (unitdef.isJavelinAtk()) {
//			if (range <= 1) {
//				int life = unitatk.getLife()-1;
//				if (life < 0) {
//					life = 0;
//				}
//				unitatk.setLife(life);
//				sX = landAtk.getX();
//				sY = landAtk.getY();
//				sU = 1;
//				myDraw();
//				try {
//					Thread.sleep(250);
//				} catch (InterruptedException e) {
//					e.printStackTrace();
//				}
//				if (unitatk.getLife()<=0) {
//					landAtk.setUnit(null);
//					landAtk.setHasUnit(false);
//					
//					BattleDrawflag = false;
//					
//					unitatk.setAttackedflag(true);
//					unitatk.setMovedflag(true);
//					
//					return;
//				}
//			}
//		}

		int damage = 0;
				
		if (unitatk.isFatalAtk() && (Math.random()*6>4)) {
			// ����
			damage = (int)((Math.random()*5)+1+1+unitatk.getAtk())*2-unitdef.getDef();
			fataFlag = true;
		} else {
			damage = (int)(Math.random()*5)+1+1+unitatk.getAtk()-unitdef.getDef();
			fataFlag = false;
		}
		
		if (damage < 0) {
			damage = 0;
		}

		int life = unitdef.getLife()-damage;
		if (life < 0) {
			life = 0;
		}
		unitdef.setLife(life);

		sX = landDef.getX();
		sY = landDef.getY();
		sU = damage;
		
		
		// ��̤
		if (unitatk.isRampleAtk()) {
			rampleFlag = true;
			
			rampleLandwayList = new ArrayList<Land>();
			rampleLandwayList.addAll(landAtk.getWay());
			if (rampleLandwayList.contains(landDef)) {
				rampleLandwayList.remove(landDef);
			}
			if (rampleLandwayList.size()>0) {
				int size = rampleLandwayList.size();
				for (int i = 0; i < size; i++)
				{
					if (rampleLandwayList.get(i).isHasUnit()) {
						int lifead = rampleLandwayList.get(i).getUnit().getLife()-1;
						if (lifead < 0) {
							lifead = 0;
						}
						rampleLandwayList.get(i).getUnit().setLife(lifead);
						//sX = rampleLandwayList.get(i).getX();
						//sY = rampleLandwayList.get(i).getY();
						//sU = 1;
						//myDraw();
						//try {
							//Thread.sleep(250);
						//} catch (InterruptedException e) {
							//e.printStackTrace();
						//}
						//if (landwayList.get(i).getUnit().getLife()<=0) {
							//landwayList.get(i).setUnit(null);
							//landwayList.get(i).setHasUnit(false);
						//}
					}
					
				}
			}
		}
		
		myDraw();
		fataFlag = false;
		rampleFlag = false;
		if (rampleLandwayList.size()>0) {
			int size = rampleLandwayList.size();
			for (int i = 0; i < size; i++)
			{
				if (rampleLandwayList.get(i).isHasUnit()) {
					if (rampleLandwayList.get(i).getUnit().getLife()<=0) {
						rampleLandwayList.get(i).setUnit(null);
						rampleLandwayList.get(i).setHasUnit(false);
					}
				}
				
			}
		}
		try {
			Thread.sleep(250);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		

		
		if (unitdef.getLife()<=0) {
			landDef.setUnit(null);
			landDef.setHasUnit(false);
		} else if(!unitdef.isCannotDefCloAtk() || range>1) {
			if (range <= unitdef.getAttackrange()) {
				
				int damagedef = 0;
		        if (unitdef.isFatalAtk() && (Math.random()*6>4)) {
		    	    // ����
		        	damagedef = (int)((Math.random()*5)+1+unitdef.getAtk())*2-unitatk.getDef();
		        	fataFlag = true;
		        } else {
		        	damagedef = (int)(Math.random()*5)+1+unitdef.getAtk()-unitatk.getDef();
		        	fataFlag = false;
	    	    }
		
				
				
				if (damagedef < 0) {
					damagedef = 0;
				}
				
				int lifedef = unitatk.getLife()-damagedef;
				if (lifedef < 0) {
					lifedef = 0;
				}
				unitatk.setLife(lifedef);

				sX = landAtk.getX();
				sY = landAtk.getY();
				sU = damagedef;
				myDraw();
				fataFlag = false;
				try {
					Thread.sleep(250);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

			}
		}
		
		
		if (unitatk.getLife()<=0) {
			landAtk.setUnit(null);
			landAtk.setHasUnit(false);
		} else if (unitatk.isDoubleAtk() && unitdef.getLife()>0) {
			// �ڶ��ι���
			int sedamage = (int)(Math.random()*5)+1+1+unitatk.getAtk()-unitdef.getDef();
			if (sedamage < 0) {
				sedamage = 0;
			}
			int selife = unitdef.getLife()-sedamage;
			if (selife < 0) {
				selife = 0;
			}
			unitdef.setLife(selife);

			sX = landDef.getX();
			sY = landDef.getY();
			sU = sedamage;
			myDraw();
			try {
				Thread.sleep(250);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			if (unitdef.getLife()<=0) {
				landDef.setUnit(null);
				landDef.setHasUnit(false);
			}
		}
		
		BattleDrawflag = false;
		
		unitatk.setAttackedflag(true);
		unitatk.setMovedflag(true);
	}
	
	private void findway(List<Land> declandwayList, List<Land> landwayList, Land landstrFrom, Land landTo, int setmovement,int movement,int own,int camp){
		setmovement++;
		List<Land> way1 = landstrFrom.getWay();
		for (int n = 0; n < way1.size(); n++) {
			Land land = way1.get(n);
			// TODO
			if ((land.getLandType()==0) && ((!land.isHasUnit()) || (land.isHasUnit() && land.getUnit().getOwner()==own) || (land.isHasUnit() && land.getUnit().getCamp()==camp)) && (!landwayList.contains(land))) {
						if (land.equals(landTo)) {
							landwayList.add(land);
							if (declandwayList.size()==0 || declandwayList.size()>landwayList.size()){
								declandwayList.clear();
								declandwayList.addAll(landwayList);
							}
							landwayList.remove(landwayList.size()-1);
						} else {
							if (setmovement<movement){
								landwayList.add(land);
								findway(declandwayList,landwayList,land,landTo,setmovement,movement,own,camp);
							}
						}

			}
			if (n+1==way1.size()) {
				landwayList.remove(landwayList.size()-1);
			}

		}
		
	}
	
	private void move(Land landFrom, Land landTo) {
		
		List<Land> declandwayList = new ArrayList<Land>();
		List<Land> landwayList = new ArrayList<Land>();
		
		int own = landFrom.getUnit().getOwner();
		//add
		int camp = landFrom.getUnit().getCamp();
		int movement = landFrom.getUnit().getMovement();
		int setmovement = 0;
		
		landwayList.add(landFrom);
		findway(declandwayList,landwayList,landFrom,landTo,setmovement,movement,own,camp);
		
		if (declandwayList.size()>0) {
			MoveDrawflag = true;
			boolean b = true;
			Unit unit = declandwayList.get(0).getUnit();
			sU = unit.getType();
			for (int i=0; i<declandwayList.size(); i++) {
				sX = declandwayList.get(i).getX();
				sY = declandwayList.get(i).getY();
				if (b) {
					i--;
					b = false;
				} else {
					int tX = 0;
					int tY = 0;
					if (i+1==declandwayList.size()){
						tX = declandwayList.get(i).getX();
						tY = declandwayList.get(i).getY();
					} else {
						tX = declandwayList.get(i+1).getX();
						tY = declandwayList.get(i+1).getY();
					}
					if (tX > sX) {
						sX = sX + (float)0.5;
					} else if (tX < sX) {
						sX = sX - (float)0.5;
					}
					if (tY > sY) {
						sY = sY + (float)0.5;
					} else if (tY < sY) {
						sY = sY - (float)0.5;
					}
					b = true;
				}
				myDraw();
			}
		}
		MoveDrawflag = false;

		Unit unit = landFrom.getUnit();
		landFrom.setUnit(null);
		landFrom.setHasUnit(false);
		landFrom.setHasSelected(false);
		unit.setMovedflag(true);
		landTo.setUnit(unit);
		landTo.setHasUnit(true);
		landTo.setHasSelected(true);
		if (landTo.isHasTown()){
			landTo.getTown().setOwner(unit.getOwner());
					//add
			landTo.getTown().setCamp(unit.getCamp());	
		}
	}
	
	// stateNo ������ 
	// touchx ����x���� touchy ����y����
	private void townOpration (int stateNo, int touchx, int touchy) {
		for (int j = 0; j < landList.size(); j++)
		{
			Land landsel = landList.get(j);
			// �ɲ����ĳ���
			if (landsel.isHasSelected() && landsel.isHasTown() && !landsel.isHasUnit() && landsel.getTown().getOwner()==0) {
				
				List<Integer> state = landsel.getTown().getTownState();

				// ���� ��Ӫ2
				if (PLAYERLIST.get(0)==2) {
					// ����ѵ��1����λ
					if (state.get(stateNo) == 1) {
						if (goldList.get(0)>=10) {
							goldList.set(0, goldList.get(0)-10);
							Unit unit = new Unit(0,11,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
						// ����ѵ��2����λ
					} else if (state.get(stateNo) == 2) {
						if (goldList.get(0)>=10) {
							goldList.set(0, goldList.get(0)-10);
							Unit unit = new Unit(0,12,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
						// ����ѵ��3����λ
					} else if (state.get(stateNo) == 3) {
						if (goldList.get(0)>=10) {
							goldList.set(0, goldList.get(0)-10);
							Unit unit = new Unit(0,13,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
						// ����ѵ��4����λ
					} else if (state.get(stateNo) == 4) {
						if (goldList.get(0)>=16) {
							goldList.set(0, goldList.get(0)-16);
							Unit unit = new Unit(0,14,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
						// ����ѵ��5����λ
					} else if (state.get(stateNo) == 5) {
						if (goldList.get(0)>=16) {
							goldList.set(0, goldList.get(0)-16);
							Unit unit = new Unit(0,15,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
						// ����ѵ��
					} else {
						for (int m = 0; m < landList.size(); m++)
						{
							Land landselm = landList.get(m);
							landselm.setHasSelected(false);
							landselm.setCanMove(false);
						}
						playerState0Action(touchx,touchy);
					}
				// ��Ӫ3
				} else if (PLAYERLIST.get(0)==3) {
					if (state.get(stateNo) == 1) {
						if (goldList.get(0)>=10) {
							goldList.set(0, goldList.get(0)-10);
							Unit unit = new Unit(0,21,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
					} else if (state.get(stateNo) == 2) {
						if (goldList.get(0)>=10) {
							goldList.set(0, goldList.get(0)-10);
							Unit unit = new Unit(0,22,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
					} else if (state.get(stateNo) == 3) {
						if (goldList.get(0)>=13) {
							goldList.set(0, goldList.get(0)-13);
							Unit unit = new Unit(0,23,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
					} else if (state.get(stateNo) == 4) {
						if (goldList.get(0)>=12) {
							goldList.set(0, goldList.get(0)-12);
							Unit unit = new Unit(0,24,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
					} else if (state.get(stateNo) == 5) {
						if (goldList.get(0)>=14) {
							goldList.set(0, goldList.get(0)-14);
							Unit unit = new Unit(0,25,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
					} else {
						for (int m = 0; m < landList.size(); m++)
						{
							Land landselm = landList.get(m);
							landselm.setHasSelected(false);
							landselm.setCanMove(false);
						}
						playerState0Action(touchx,touchy);
					}
					// ��Ӫ4
				} else if (PLAYERLIST.get(0)==4) {
					if (state.get(stateNo) == 1) {
						if (goldList.get(0)>=10) {
							goldList.set(0, goldList.get(0)-10);
							Unit unit = new Unit(0,31,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
					} else if (state.get(stateNo) == 2) {
						if (goldList.get(0)>=10) {
							goldList.set(0, goldList.get(0)-10);
							Unit unit = new Unit(0,32,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
					} else if (state.get(stateNo) == 3) {
						if (goldList.get(0)>=15) {
							goldList.set(0, goldList.get(0)-15);
							Unit unit = new Unit(0,33,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
					} else if (state.get(stateNo) == 4) {
						if (goldList.get(0)>=12) {
							goldList.set(0, goldList.get(0)-12);
							Unit unit = new Unit(0,34,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
					} else if (state.get(stateNo) == 5) {
						if (goldList.get(0)>=17) {
							goldList.set(0, goldList.get(0)-17);
							Unit unit = new Unit(0,35,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
					} else {
						for (int m = 0; m < landList.size(); m++)
						{
							Land landselm = landList.get(m);
							landselm.setHasSelected(false);
							landselm.setCanMove(false);
						}
						playerState0Action(touchx,touchy);
					}
					// ��Ӫ5
				} else if (PLAYERLIST.get(0)==5) {
					if (state.get(stateNo) == 1) {
						if (goldList.get(0)>=10) {
							goldList.set(0, goldList.get(0)-10);
							Unit unit = new Unit(0,41,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
					} else if (state.get(stateNo) == 2) {
						if (goldList.get(0)>=10) {
							goldList.set(0, goldList.get(0)-10);
							Unit unit = new Unit(0,42,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
					} else if (state.get(stateNo) == 3) {
						if (goldList.get(0)>=15) {
							goldList.set(0, goldList.get(0)-15);
							Unit unit = new Unit(0,43,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
					} else if (state.get(stateNo) == 4) {
						if (goldList.get(0)>=13) {
							goldList.set(0, goldList.get(0)-13);
							Unit unit = new Unit(0,44,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
					} else if (state.get(stateNo) == 5) {
						if (goldList.get(0)>=17) {
							goldList.set(0, goldList.get(0)-17);
							Unit unit = new Unit(0,45,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
					} else {
						for (int m = 0; m < landList.size(); m++)
						{
							Land landselm = landList.get(m);
							landselm.setHasSelected(false);
							landselm.setCanMove(false);
						}
						playerState0Action(touchx,touchy);
					}
				} else if (PLAYERLIST.get(0)==6) {// ��Ӫ6
					if (state.get(stateNo) == 1) {
						if (goldList.get(0)>=10) {
							goldList.set(0, goldList.get(0)-10);
							Unit unit = new Unit(0,51,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
					} else if (state.get(stateNo) == 2) {
						if (goldList.get(0)>=10) {
							goldList.set(0, goldList.get(0)-10);
							Unit unit = new Unit(0,52,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
					} else if (state.get(stateNo) == 3) {
						if (goldList.get(0)>=15) {
							goldList.set(0, goldList.get(0)-15);
							Unit unit = new Unit(0,53,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
					} else if (state.get(stateNo) == 4) {
						if (goldList.get(0)>=13) {
							goldList.set(0, goldList.get(0)-13);
							Unit unit = new Unit(0,54,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
					} else if (state.get(stateNo) == 5) {
						if (goldList.get(0)>=17) {
							goldList.set(0, goldList.get(0)-17);
							Unit unit = new Unit(0,55,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
					} else {
						for (int m = 0; m < landList.size(); m++)
						{
							Land landselm = landList.get(m);
							landselm.setHasSelected(false);
							landselm.setCanMove(false);
						}
						playerState0Action(touchx,touchy);
					}
				} else if (PLAYERLIST.get(0)==7) {// ��Ӫ7
					if (state.get(stateNo) == 1) {
						if (goldList.get(0)>=10) {
							goldList.set(0, goldList.get(0)-10);
							Unit unit = new Unit(0,61,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
					} else if (state.get(stateNo) == 2) {
						if (goldList.get(0)>=10) {
							goldList.set(0, goldList.get(0)-10);
							Unit unit = new Unit(0,62,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
					} else if (state.get(stateNo) == 3) {
						if (goldList.get(0)>=15) {
							goldList.set(0, goldList.get(0)-15);
							Unit unit = new Unit(0,63,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
					} else if (state.get(stateNo) == 4) {
						if (goldList.get(0)>=13) {
							goldList.set(0, goldList.get(0)-13);
							Unit unit = new Unit(0,64,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
					} else if (state.get(stateNo) == 5) {
						if (goldList.get(0)>=18) {
							goldList.set(0, goldList.get(0)-18);
							Unit unit = new Unit(0,65,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
					} else {
						for (int m = 0; m < landList.size(); m++)
						{
							Land landselm = landList.get(m);
							landselm.setHasSelected(false);
							landselm.setCanMove(false);
						}
						playerState0Action(touchx,touchy);
					}
				} else {// ��Ӫ1
					if (state.get(stateNo) == 1) {
						if (goldList.get(0)>=10) {
							goldList.set(0, goldList.get(0)-10);
							Unit unit = new Unit(0,1,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
					} else if (state.get(stateNo) == 2) {
						if (goldList.get(0)>=10) {
							goldList.set(0, goldList.get(0)-10);
							Unit unit = new Unit(0,2,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
					} else if (state.get(stateNo) == 3) {
						if (goldList.get(0)>=15) {
							goldList.set(0, goldList.get(0)-15);
							Unit unit = new Unit(0,3,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
					} else if (state.get(stateNo) == 4) {
						if (goldList.get(0)>=13) {
							goldList.set(0, goldList.get(0)-13);
							Unit unit = new Unit(0,4,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
					} else if (state.get(stateNo) == 5) {
						if (goldList.get(0)>=17) {
							goldList.set(0, goldList.get(0)-17);
							Unit unit = new Unit(0,5,0);
							unit.setMovedflag(true);
							unit.setAttackedflag(true);
							// unit
							landsel.setHasUnit(true);
							landsel.setUnit(unit);
						}
					} else {
						for (int m = 0; m < landList.size(); m++)
						{
							Land landselm = landList.get(m);
							landselm.setHasSelected(false);
							landselm.setCanMove(false);
						}
						playerState0Action(touchx,touchy);
					}
				}
				
			}
		}
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		if ((event.getAction() == MotionEvent.ACTION_DOWN) && !AIflag && (aiNo == 1)) {
			int touchx = (int) event.getX();
			int touchy = (int) event.getY();
			if (restartflag){
				if ((4*PIXEL_UNIT < touchx && touchx < (4*PIXEL_UNIT+PIXEL_UNIT)) && (4*PIXEL_UNIT < touchy && touchy < (4*PIXEL_UNIT+PIXEL_UNIT))){
					HARD = 0;
					BATTLEFIELD = false;
				} else if ((5*PIXEL_UNIT < touchx && touchx < (5*PIXEL_UNIT+PIXEL_UNIT)) && (4*PIXEL_UNIT < touchy && touchy < (4*PIXEL_UNIT+PIXEL_UNIT))){
					HARD = 2;
					BATTLEFIELD = false;
				} else if ((6*PIXEL_UNIT < touchx && touchx < (6*PIXEL_UNIT+PIXEL_UNIT)) && (4*PIXEL_UNIT < touchy && touchy < (4*PIXEL_UNIT+PIXEL_UNIT))){
					HARD = 3;
					BATTLEFIELD = false;
				} else if ((4*PIXEL_UNIT < touchx && touchx < (4*PIXEL_UNIT+PIXEL_UNIT)) && (5*PIXEL_UNIT < touchy && touchy < (5*PIXEL_UNIT+PIXEL_UNIT))){
					MAXAI = 1;
					TwoVTwo = false;
					BATTLEFIELD = false;
				} else if ((5*PIXEL_UNIT < touchx && touchx < (5*PIXEL_UNIT+PIXEL_UNIT)) && (5*PIXEL_UNIT < touchy && touchy < (5*PIXEL_UNIT+PIXEL_UNIT))){
					MAXAI = 3;
					TwoVTwo = false;
					BATTLEFIELD = false;
				} else if ((6*PIXEL_UNIT < touchx && touchx < (6*PIXEL_UNIT+PIXEL_UNIT)) && (5*PIXEL_UNIT < touchy && touchy < (5*PIXEL_UNIT+PIXEL_UNIT))){
					MAXAI = 3;
					TwoVTwo = true;
					BATTLEFIELD = false;
				} else if ((3*PIXEL_UNIT < touchx && touchx < (3*PIXEL_UNIT+PIXEL_UNIT)) && (6*PIXEL_UNIT < touchy && touchy < (6*PIXEL_UNIT+PIXEL_UNIT))){
					SIZE = 5;
					BATTLEFIELD = false;
				} else if ((4*PIXEL_UNIT < touchx && touchx < (4*PIXEL_UNIT+PIXEL_UNIT)) && (6*PIXEL_UNIT < touchy && touchy < (6*PIXEL_UNIT+PIXEL_UNIT))){
					SIZE = 7;
					BATTLEFIELD = false;
				} else if ((5*PIXEL_UNIT < touchx && touchx < (5*PIXEL_UNIT+PIXEL_UNIT)) && (6*PIXEL_UNIT < touchy && touchy < (6*PIXEL_UNIT+PIXEL_UNIT))){
					SIZE = 9;
					BATTLEFIELD = false;
				} else if ((6*PIXEL_UNIT < touchx && touchx < (6*PIXEL_UNIT+PIXEL_UNIT)) && (6*PIXEL_UNIT < touchy && touchy < (6*PIXEL_UNIT+PIXEL_UNIT))){
					SIZE = 11;
					BATTLEFIELD = false;
				} else if ((2*PIXEL_UNIT < touchx && touchx < (2*PIXEL_UNIT+PIXEL_UNIT)) && (7*PIXEL_UNIT < touchy && touchy < (7*PIXEL_UNIT+PIXEL_UNIT))){
					if(PLAYER1 == 0){
						PLAYER1 = 7;
					}else{
						PLAYER1 = PLAYER1 - 1;
					}
//				} else if ((3*PIXEL_UNIT < touchx && touchx < (3*PIXEL_UNIT+PIXEL_UNIT)) && (7*PIXEL_UNIT < touchy && touchy < (7*PIXEL_UNIT+PIXEL_UNIT))){
//					PLAYER1 = 2;
				} else if ((4*PIXEL_UNIT < touchx && touchx < (4*PIXEL_UNIT+PIXEL_UNIT)) && (7*PIXEL_UNIT < touchy && touchy < (7*PIXEL_UNIT+PIXEL_UNIT))){
					if(PLAYER1 == 7){
						PLAYER1 = 0;
					}else{
						PLAYER1 = PLAYER1 + 1;
					}
//				} else if ((5*PIXEL_UNIT < touchx && touchx < (5*PIXEL_UNIT+PIXEL_UNIT)) && (7*PIXEL_UNIT < touchy && touchy < (7*PIXEL_UNIT+PIXEL_UNIT))){
//					PLAYER1 = 4;
//				} else if ((6*PIXEL_UNIT < touchx && touchx < (6*PIXEL_UNIT+PIXEL_UNIT)) && (7*PIXEL_UNIT < touchy && touchy < (7*PIXEL_UNIT+PIXEL_UNIT))){
//					PLAYER1 = 5;// unit
//				} else if ((2*PIXEL_UNIT < touchx && touchx < (2*PIXEL_UNIT+PIXEL_UNIT)) && (8*PIXEL_UNIT < touchy && touchy < (8*PIXEL_UNIT+PIXEL_UNIT))){
//					PLAYER1 = 6;// unit
//				} else if ((3*PIXEL_UNIT < touchx && touchx < (3*PIXEL_UNIT+PIXEL_UNIT)) && (8*PIXEL_UNIT < touchy && touchy < (8*PIXEL_UNIT+PIXEL_UNIT))){
//					PLAYER1 = 7;// unit
				} else if ((4*PIXEL_UNIT < touchx && touchx < (4*PIXEL_UNIT+PIXEL_UNIT)) && (3*PIXEL_UNIT < touchy && touchy < (3*PIXEL_UNIT+PIXEL_UNIT))){
					BATTLEFIELD = false;
					HARD = 0;
					MAXAI = 1;
					SIZE = 9;
				} else if ((5*PIXEL_UNIT < touchx && touchx < (5*PIXEL_UNIT+PIXEL_UNIT)) && (3*PIXEL_UNIT < touchy && touchy < (3*PIXEL_UNIT+PIXEL_UNIT))){
					BATTLEFIELD = true;
					HARD = 0;
					MAXAI = 1;
					SIZE = 9;
				} else if ((5*PIXEL_UNIT < touchx && touchx < (5*PIXEL_UNIT+PIXEL_UNIT)) && (9*PIXEL_UNIT < touchy && touchy < (9*PIXEL_UNIT+PIXEL_UNIT))){
					restartflag = false;
					restrat(false);
				} else if ((6*PIXEL_UNIT < touchx && touchx < (6*PIXEL_UNIT+PIXEL_UNIT)) && (9*PIXEL_UNIT < touchy && touchy < (9*PIXEL_UNIT+PIXEL_UNIT))){
					restartflag = false;
					restrat(true);
				}
				this.run();
				return true;
			} else {
				// save
				if ((9*PIXEL_UNIT < touchx && touchx < (9*PIXEL_UNIT+PIXEL_UNIT)) && (12*PIXEL_UNIT < touchy && touchy < (12*PIXEL_UNIT+PIXEL_UNIT))){
					saveGame();
				}
				 //if ((7*PIXEL_UNIT < touchx && touchx < (7*PIXEL_UNIT+PIXEL_UNIT)) && (12*PIXEL_UNIT < touchy && touchy < (12*PIXEL_UNIT+PIXEL_UNIT))){
				//	saveGame();
				 //}
				// �����غ�
				 else if ((8*PIXEL_UNIT < touchx && touchx < (8*PIXEL_UNIT+PIXEL_UNIT)) && (12*PIXEL_UNIT < touchy && touchy < (12*PIXEL_UNIT+PIXEL_UNIT))){
					

					AIflag = true;
					
					for (int i = 0; i < landList.size(); i++)
					{
						Land land = landList.get(i);
						land.setHasSelected(false);
						land.setCanMove(false);
						if (land.isHasUnit()) {
							// δ�ж���λ�����ظ�
							if (land.getUnit().getOwner()==0 && !land.getUnit().isMovedflag()) {
								int life = land.getUnit().getLife();
								int maxlife = land.getUnit().getMaxlife();
								life = life+1;
								if (life > maxlife) {
									life = maxlife;
								}
								land.getUnit().setLife(life);
							}
							land.getUnit().setMovedflag(false);
							land.getUnit().setAttackedflag(false);

							if (land.getUnit().getOwner()==0 && land.getUnit().isRecover()) {
								int life = land.getUnit().getLife();
								int maxlife = land.getUnit().getMaxlife();
								life = life+2;
								if (life > maxlife) {
									life = maxlife;
								}
								land.getUnit().setLife(life);
							}
						}
					}
					
					playerState = 0;
				
			} else if ((7*PIXEL_UNIT < touchx && touchx < (7*PIXEL_UNIT+PIXEL_UNIT)) && (12*PIXEL_UNIT < touchy && touchy < (12*PIXEL_UNIT+PIXEL_UNIT))) {
				
				for (int i = 0; i < landList.size(); i++)
				{
					Land land = landList.get(i);
					if (land.isHasSelected() && land.isHasTown() && land.getTown().getOwner()==0) {
						Town town = land.getTown();
						List<Integer> state = town.getTownState();
						if (state.get(7) == 84) {
							if (goldList.get(0)>=10) {
								state.set(7, state.get(7)+1);
								town.setTurnGoldUp(town.getTurnGoldUp()+2);
								goldList.set(0, goldList.get(0)-10);
							}
						} else if (state.get(7) == 85) {
							if (goldList.get(0)>=15) {
								state.set(7, state.get(7)+1);
								town.setTurnGoldUp(town.getTurnGoldUp()+2);
								goldList.set(0, goldList.get(0)-15);
							}
						} else {
							for (int j = 0; j < landList.size(); j++)
							{
								Land landsel = landList.get(j);
								landsel.setHasSelected(false);
								landsel.setCanMove(false);
							}
							playerState0Action(touchx,touchy);
						}
					}
				}
				

				
			} else if ((6*PIXEL_UNIT < touchx && touchx < (6*PIXEL_UNIT+PIXEL_UNIT)) && (12*PIXEL_UNIT < touchy && touchy < (12*PIXEL_UNIT+PIXEL_UNIT))) {
				
				for (int i = 0; i < landList.size(); i++)
				{
					Land land = landList.get(i);
					if (land.isHasSelected() && land.isHasTown() && land.getTown().getOwner()==0) {
						Town town = land.getTown();
						List<Integer> state = town.getTownState();
						// unit
						if (state.get(6) == 81) {
							if (goldList.get(0)>=5) {
								state.set(6, state.get(6)+1);
								state.set(2, 3);
								state.set(3, 4);
								goldList.set(0, goldList.get(0)-5);
							}
						} else if (state.get(6) == 82) {
							if (goldList.get(0)>=10) {
								state.set(6, state.get(6)+1);
								state.set(4, 5);
								goldList.set(0, goldList.get(0)-10);
							}
						} else {
							for (int j = 0; j < landList.size(); j++)
							{
								Land landsel = landList.get(j);
								landsel.setHasSelected(false);
								landsel.setCanMove(false);
							}
							playerState0Action(touchx,touchy);
						}
					}
				}
				

				
			}
//			else if ((0 < touchx && touchx < (0+50)) && (525 < touchy && touchy < (525+50))) {
//				//sp TODO
//				if (spList.get(0)>=10) {
//					for (int i = 0; i < landList.size(); i++)
//					{
//						Land land = landList.get(i);
//						land.setHasSelected(false);
//						land.setCanMove(false);
//					}
//					for (int i = 0; i < landList.size(); i++)
//					{
//						Land land = landList.get(i);
//						if (land.isHasUnit() && land.getUnit().getOwner()==0 && land.getUnit().getLife() != land.getUnit().getMaxlife()) {
//							land.setCanMove(true);
//						}
//					}
//					nowsp = 1;
//					playerState = 3;
//					
//				}
//
//			}

			else {
				if (playerState == 0) {
					playerState0Action(touchx,touchy);
				} else if (playerState == 1) {
					
					for (int i = 0; i < landList.size(); i++)
					{
						Land land = landList.get(i);
						int x = land.getX();
						int y = land.getY();

						if (((x)*PIXEL_UNIT < touchx && touchx < ((x)*PIXEL_UNIT+PIXEL_UNIT)) && ((y)*PIXEL_UNIT < touchy && touchy < ((y)*PIXEL_UNIT+PIXEL_UNIT))){
							
							if (land.isCanMove()) {
								
								if (land.isHasUnit() && land.getUnit().getOwner()!=0 && land.getUnit().getCamp()!=0) {
									for (int j = 0; j < landList.size(); j++)
									{
										Land landselect = landList.get(j);
										if (landselect.isHasSelected() && landselect.isHasUnit()) {

											battle(landselect,land);
											
											landselect.setHasSelected(false);
											
											for (int m = 0; m < landList.size(); m++)
											{
												Land landsetmove = landList.get(m);
												landsetmove.setCanMove(false);
											}
										}
									}
								} else {
									for (int j = 0; j < landList.size(); j++)
									{
										Land landselect = landList.get(j);
										if (landselect.isHasSelected() && landselect.isHasUnit()) {
											Unit unit = landselect.getUnit();
											if (!unit.isMovedflag()) {
											     move(landselect,land);
											}
										}
									}
									
									for (int j = 0; j < landList.size(); j++)
									{
										Land landmove = landList.get(j);
										if (landmove.isCanMove()) {
											landmove.setCanMove(false);
										}
									}
									
									for (int j = 0; j < landList.size(); j++)
									{
										Land landselect = landList.get(j);
										if (landselect.isHasSelected() && landselect.isHasUnit()) {
											atkRangeSet(landselect);
											landselect.setCanMove(false);
										}
									}
								}
								

							} else {
								for (int j = 0; j < landList.size(); j++)
								{
									Land landsel = landList.get(j);
									landsel.setHasSelected(false);
									landsel.setCanMove(false);
								}

								playerState0Action(touchx,touchy);
							}
							

						}
						
						
					}


				} else if (playerState == 2) {
					// unit
					if ((0 < touchx && touchx < (0+PIXEL_UNIT)) && (12*PIXEL_UNIT < touchy && touchy < (12*PIXEL_UNIT+PIXEL_UNIT))){
						townOpration(0, touchx, touchy);
					} else if ((PIXEL_UNIT < touchx && touchx < (PIXEL_UNIT+PIXEL_UNIT)) && (12*PIXEL_UNIT < touchy && touchy < (12*PIXEL_UNIT+PIXEL_UNIT))){
						townOpration(1, touchx, touchy);
					} else if ((2*PIXEL_UNIT < touchx && touchx < (2*PIXEL_UNIT+PIXEL_UNIT)) && (12*PIXEL_UNIT < touchy && touchy < (12*PIXEL_UNIT+PIXEL_UNIT))){
						townOpration(2, touchx, touchy);
					} else if ((3*PIXEL_UNIT < touchx && touchx < (3*PIXEL_UNIT+PIXEL_UNIT)) && (12*PIXEL_UNIT < touchy && touchy < (12*PIXEL_UNIT+PIXEL_UNIT))){
						townOpration(3, touchx, touchy);
					}  else if ((4*PIXEL_UNIT < touchx && touchx < (4*PIXEL_UNIT+PIXEL_UNIT)) && (12*PIXEL_UNIT < touchy && touchy < (12*PIXEL_UNIT+PIXEL_UNIT))){
						townOpration(4, touchx, touchy);
					}  else if ((5*PIXEL_UNIT < touchx && touchx < (5*PIXEL_UNIT+PIXEL_UNIT)) && (12*PIXEL_UNIT < touchy && touchy < (12*PIXEL_UNIT+PIXEL_UNIT))){
						townOpration(5, touchx, touchy);
					} else {// ����ѡ��
						for (int j = 0; j < landList.size(); j++)
						{
							Land landsel = landList.get(j);
							landsel.setHasSelected(false);
							landsel.setCanMove(false);
						}
						playerState0Action(touchx,touchy);
					}
				}
//				else if (playerState == 3) {
//					for (int i = 0; i < landList.size(); i++)
//					{
//						Land land = landList.get(i);
//						int x = land.getX();
//						int y = land.getY();
//
//						if (((x)*50 < touchx && touchx < ((x)*50+50)) && ((y)*50 < touchy && touchy < ((y)*50+50))){
//							
//							if (land.isCanMove()) {
//								int life = land.getUnit().getLife();
//								int maxlife = land.getUnit().getMaxlife();
//								life = life+5;
//								if (life > maxlife) {
//									life = maxlife;
//								}
//								land.getUnit().setLife(life);
//								spList.set(0, spList.get(0)-10);
//							}
//						}
//					}
//					
//					for (int i = 0; i < landList.size(); i++)
//					{
//						Land land = landList.get(i);
//						land.setHasSelected(false);
//						land.setCanMove(false);
//					}
//					nowsp = 0;
//					playerState = 0;
//				}
			}
			this.run();
			return true;
		}
		} else {
			return true;
		}
	}


	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		return super.onKeyDown(keyCode, event);
	}
	
	// ai��ѡ��Ӫ
	private void aiBuyUnit_TownNoUnit(int nowAINo){
		for (int i = 0; i < landList.size(); i++)
		{
			if (goldList.get(nowAINo)>=10) {
				Land land = landList.get(i);
				if (land.isHasTown() && land.getTown().getOwner()==nowAINo && land.getTown().getType()==1){
					
					Town town = land.getTown();
					List<Integer> stateList = town.getTownState();
					int checkstate = (int)(Math.random()*stateList.size());
					int state = stateList.get(checkstate);
					while (state!=1 && state!=2 && state!=3 && state!=4 && state!=5) {
						checkstate = (int)(Math.random()*stateList.size());
						state = stateList.get(checkstate);
					}
					
					if (!land.isHasUnit()){
						afterUnitAction(land);
						Unit unit = new Unit(nowAINo,state,nowAINo);
						if(TwoVTwo && nowAINo==3){
							unit.setCamp(0);
						}else if(TwoVTwo){
							unit.setCamp(1);
						}
						// unit
						if (PLAYERLIST.get(nowAINo)==2) {
							state = state + 10;
							unit = new Unit(nowAINo,state,nowAINo);
							if(TwoVTwo && nowAINo==3){
								unit.setCamp(0);
							}else if(TwoVTwo){
								unit.setCamp(1);
							}
						} else if (PLAYERLIST.get(nowAINo)==3) {
							state = state + 20;
							unit = new Unit(nowAINo,state,nowAINo);
							if(TwoVTwo && nowAINo==3){
								unit.setCamp(0);
							}else if(TwoVTwo){
								unit.setCamp(1);
							}
						} else if (PLAYERLIST.get(nowAINo)==4) {
							state = state + 30;
							unit = new Unit(nowAINo,state,nowAINo);
							if(TwoVTwo && nowAINo==3){
								unit.setCamp(0);
							}else if(TwoVTwo){
								unit.setCamp(1);
							}
						} else if (PLAYERLIST.get(nowAINo)==5) {
							state = state + 40;
							unit = new Unit(nowAINo,state,nowAINo);
							if(TwoVTwo && nowAINo==3){
								unit.setCamp(0);
							}else if(TwoVTwo){
								unit.setCamp(1);
							}
						} else if (PLAYERLIST.get(nowAINo)==6) {
							state = state + 50;
							unit = new Unit(nowAINo,state,nowAINo);
							if(TwoVTwo && nowAINo==3){
								unit.setCamp(0);
							}else if(TwoVTwo){
								unit.setCamp(1);
							}
						} else if (PLAYERLIST.get(nowAINo)==7) {
							state = state + 60;
							unit = new Unit(nowAINo,state,nowAINo);
							if(TwoVTwo && nowAINo==3){
								unit.setCamp(0);
							}else if(TwoVTwo){
								unit.setCamp(1);
							}
						} else {
							unit = new Unit(nowAINo,state,nowAINo);
							if(TwoVTwo && nowAINo==3){
								unit.setCamp(0);
							}else if(TwoVTwo){
								unit.setCamp(1);
							}
						}
						unit.setState(1);
						unit.setAttackedflag(true);
						unit.setMovedflag(true);
						// unit
						if (PLAYERLIST.get(nowAINo)==2) {
							if (state==1 && goldList.get(nowAINo)>=10) {
								goldList.set(nowAINo, goldList.get(nowAINo)-10);
							} else if (state==2 && goldList.get(nowAINo)>=10) {
								goldList.set(nowAINo, goldList.get(nowAINo)-10);
							} else if (state==3 && goldList.get(nowAINo)>=10) {
								goldList.set(nowAINo, goldList.get(nowAINo)-10);
							} else if (state==4 && goldList.get(nowAINo)>=16) {
								goldList.set(nowAINo, goldList.get(nowAINo)-16);
							} else if (state==5 && goldList.get(nowAINo)>=16) {
								goldList.set(nowAINo, goldList.get(nowAINo)-16);
							}
						} else if (PLAYERLIST.get(nowAINo)==3) {
							if (state==1 && goldList.get(nowAINo)>=10) {
								goldList.set(nowAINo, goldList.get(nowAINo)-10);
							} else if (state==2 && goldList.get(nowAINo)>=10) {
								goldList.set(nowAINo, goldList.get(nowAINo)-10);
							} else if (state==3 && goldList.get(nowAINo)>=13) {
								goldList.set(nowAINo, goldList.get(nowAINo)-13);
							} else if (state==4 && goldList.get(nowAINo)>=12) {
								goldList.set(nowAINo, goldList.get(nowAINo)-12);
							} else if (state==5 && goldList.get(nowAINo)>=14) {
								goldList.set(nowAINo, goldList.get(nowAINo)-14);
							}
						} else if (PLAYERLIST.get(nowAINo)==4) {
							if (state==1 && goldList.get(nowAINo)>=10) {
								goldList.set(nowAINo, goldList.get(nowAINo)-10);
							} else if (state==2 && goldList.get(nowAINo)>=10) {
								goldList.set(nowAINo, goldList.get(nowAINo)-10);
							} else if (state==3 && goldList.get(nowAINo)>=15) {
								goldList.set(nowAINo, goldList.get(nowAINo)-15);
							} else if (state==4 && goldList.get(nowAINo)>=12) {
								goldList.set(nowAINo, goldList.get(nowAINo)-12);
							} else if (state==5 && goldList.get(nowAINo)>=17) {
								goldList.set(nowAINo, goldList.get(nowAINo)-17);
							}
						} else if (PLAYERLIST.get(nowAINo)==5) {
							if (state==1 && goldList.get(nowAINo)>=10) {
								goldList.set(nowAINo, goldList.get(nowAINo)-10);
							} else if (state==2 && goldList.get(nowAINo)>=10) {
								goldList.set(nowAINo, goldList.get(nowAINo)-10);
							} else if (state==3 && goldList.get(nowAINo)>=15) {
								goldList.set(nowAINo, goldList.get(nowAINo)-15);
							} else if (state==4 && goldList.get(nowAINo)>=13) {
								goldList.set(nowAINo, goldList.get(nowAINo)-13);
							} else if (state==5 && goldList.get(nowAINo)>=17) {
								goldList.set(nowAINo, goldList.get(nowAINo)-17);
							}
						} else if (PLAYERLIST.get(nowAINo)==6) {
							if (state==1 && goldList.get(nowAINo)>=10) {
								goldList.set(nowAINo, goldList.get(nowAINo)-10);
							} else if (state==2 && goldList.get(nowAINo)>=10) {
								goldList.set(nowAINo, goldList.get(nowAINo)-10);
							} else if (state==3 && goldList.get(nowAINo)>=15) {
								goldList.set(nowAINo, goldList.get(nowAINo)-15);
							} else if (state==4 && goldList.get(nowAINo)>=13) {
								goldList.set(nowAINo, goldList.get(nowAINo)-13);
							} else if (state==5 && goldList.get(nowAINo)>=17) {
								goldList.set(nowAINo, goldList.get(nowAINo)-17);
							}
						} else if (PLAYERLIST.get(nowAINo)==7) {
							if (state==1 && goldList.get(nowAINo)>=10) {
								goldList.set(nowAINo, goldList.get(nowAINo)-10);
							} else if (state==2 && goldList.get(nowAINo)>=10) {
								goldList.set(nowAINo, goldList.get(nowAINo)-10);
							} else if (state==3 && goldList.get(nowAINo)>=15) {
								goldList.set(nowAINo, goldList.get(nowAINo)-15);
							} else if (state==4 && goldList.get(nowAINo)>=13) {
								goldList.set(nowAINo, goldList.get(nowAINo)-13);
							} else if (state==5 && goldList.get(nowAINo)>=18) {
								goldList.set(nowAINo, goldList.get(nowAINo)-18);
							}
						} else {
							if (state==1 && goldList.get(nowAINo)>=10) {
								goldList.set(nowAINo, goldList.get(nowAINo)-10);
							} else if (state==2 && goldList.get(nowAINo)>=10) {
								goldList.set(nowAINo, goldList.get(nowAINo)-10);
							} else if (state==3 && goldList.get(nowAINo)>=15) {
								goldList.set(nowAINo, goldList.get(nowAINo)-15);
							} else if (state==4 && goldList.get(nowAINo)>=13) {
								goldList.set(nowAINo, goldList.get(nowAINo)-13);
							} else if (state==5 && goldList.get(nowAINo)>=17) {
								goldList.set(nowAINo, goldList.get(nowAINo)-17);
							}
						}

						land.setHasUnit(true);
						land.setUnit(unit);
						
						aiNextGoldDo = 0;
					}
				}
			}
		}
	}

	private void aiBuyUnit_TownHasUnit(int nowAINo,int nowAICamp){
		
		// ���������ĳ���
		List<Land> townList = new ArrayList<Land>();
		for (int i = 0; i < landList.size(); i++)
		{
			Land land = landList.get(i);
			if (land.isHasTown() && land.getTown().getOwner()==nowAINo && land.getTown().getType()==1){
				townList.add(land);
			}
		}
		
		if (townList.size()>0) {

			// ����
			int tryupg = (int)(Math.random()*3);
			if (tryupg>1) {
				int checktown = (int)(Math.random()*townList.size());
				Town town = townList.get(checktown).getTown();
				List<Integer> stateList = town.getTownState();
				if (stateList.contains(81) || stateList.contains(82) || stateList.contains(84) || stateList.contains(85)) {
					int checkstate = (int)(Math.random()*stateList.size());
					int state = stateList.get(checkstate);
					while (state!=81 && state!=84 && state!=82 && state!=85) {
						checkstate = (int)(Math.random()*stateList.size());
						state = stateList.get(checkstate);
					}
					// unit
					if (state == 84) {
						if (goldList.get(nowAINo)>=10) {
							stateList.set(7, stateList.get(7)+1);
							town.setTurnGoldUp(town.getTurnGoldUp()+2);
							goldList.set(nowAINo, goldList.get(nowAINo)-10);
							aiNextGoldDo = 0;
						}
					} else if (state == 85) {
						if (goldList.get(nowAINo)>=15) {
							stateList.set(7, stateList.get(7)+1);
							town.setTurnGoldUp(town.getTurnGoldUp()+2);
							goldList.set(nowAINo, goldList.get(nowAINo)-15);
							aiNextGoldDo = 0;
						}
					} else if (state == 81) {
						if (goldList.get(nowAINo)>=5) {
							stateList.set(6, stateList.get(6)+1);
							stateList.set(2, 3);
							stateList.set(3, 4);
							goldList.set(nowAINo, goldList.get(nowAINo)-5);
							aiNextGoldDo = 0;
						}
					} else if (state == 82) {
						if (goldList.get(nowAINo)>=10) {
							stateList.set(6, stateList.get(6)+1);
							stateList.set(4, 5);
							goldList.set(nowAINo, goldList.get(nowAINo)-10);
							aiNextGoldDo = 0;
						}
					}
				}
			}
			
			//
			if (townList.size()>0) {
				for (int i = 0; i < townList.size(); i++)
				{
					Land land = townList.get(i);
					if (land.isHasUnit() && land.getUnit().isMovedflag()) {
						townList.remove(land);
					}
				}
			}
			//
			
			while (townList.size()>0) {
				
				int shortWay = 1000;
				Land landDecBudTown = null;
				
				for (int i = 0; i < townList.size(); i++)
				{
					Land land = townList.get(i);

					int x = land.getX();
					int y = land.getY();

					for (int j = 0; j < landList.size(); j++)
					{
						Land landt = landList.get(j);
						if (landt.isHasTown() && landt.getTown().getOwner()!=nowAINo && landt.getTown().getCamp()!= nowAICamp) {
							int tx = landt.getX();
							int ty = landt.getY();
							if ((Math.abs(x-tx) + Math.abs(y-ty))<shortWay){
								shortWay = Math.abs(x-tx) + Math.abs(y-ty);
								landDecBudTown = land;
							} else if ((Math.abs(x-tx) + Math.abs(y-ty))==shortWay) {
								if ((int)(Math.random()*2)>=1) {
									shortWay = Math.abs(x-tx) + Math.abs(y-ty);
									landDecBudTown = land;
								}
							}
						}
					}
				}
				
				if (landDecBudTown==null) {
					return;
				}
				
				List<Integer> stateList = landDecBudTown.getTown().getTownState();
				List<Integer> budList = new ArrayList<Integer>();
				// unit
				if (stateList.contains(1)) {
					budList.add(1);
				}
				if (stateList.contains(2)) {
					budList.add(2);
				}
				if (stateList.contains(3)) {
					budList.add(3);
				}
				if (stateList.contains(4)) {
					budList.add(4);
				}
				if (stateList.contains(5)) {
					budList.add(5);
				}
				if (budList.size()>0) {
					if (!budList.contains(aiNextGoldDo)){
						int checkbud = (int)(Math.random()*budList.size());
						aiNextGoldDo = budList.get(checkbud);
					}
				}
				if (aiNextGoldDo == 1) {
					aiBuyUnit(nowAINo, 1, 10, landDecBudTown, nowAICamp);
				} else if (aiNextGoldDo == 2) {
					aiBuyUnit(nowAINo, 2, 10, landDecBudTown, nowAICamp);
				} else if (aiNextGoldDo == 3) {
					aiBuyUnit(nowAINo, 3, 15, landDecBudTown, nowAICamp);
				} else if (aiNextGoldDo == 4) {
					aiBuyUnit(nowAINo, 4, 13, landDecBudTown, nowAICamp);
				} else if (aiNextGoldDo == 5) {
					aiBuyUnit(nowAINo, 5, 17, landDecBudTown, nowAICamp);
				}
				
				townList.remove(landDecBudTown);
			}

		}
	}
	
	private void aiBuyUnit(int nowAINo, int type, int cost, Land land, int nowAICamp){
		if (goldList.get(nowAINo)>=cost) {
			if (land.isHasTown() && land.getTown().getOwner()==nowAINo){
				if (!land.isHasUnit() || (land.isHasUnit() && !land.getUnit().isMovedflag())){
					if (land.isHasUnit()) {
						land.getUnit().setState(0);
					}
					aiUnitState0Action(land, nowAINo, nowAICamp);
					if (land.isHasUnit() && !land.getUnit().isAttackedflag()) {
						aiUnitState2Action(land, nowAINo, nowAICamp);
					}
					afterUnitAction(land);
					if (!land.isHasUnit()) {
						afterUnitAction(land);
						Unit unit = new Unit(nowAINo,type,nowAINo);
						if(TwoVTwo && nowAINo==3){
							unit.setCamp(0);
						}else if(TwoVTwo){
							unit.setCamp(1);
						}
						// unit
						if (PLAYERLIST.get(nowAINo)==2) {
							type = type + 10;
							unit = new Unit(nowAINo,type,nowAINo);
							if(TwoVTwo && nowAINo==3){
								unit.setCamp(0);
							}else if(TwoVTwo){
								unit.setCamp(1);
							}
						} else if (PLAYERLIST.get(nowAINo)==3) {
							type = type + 20;
							unit = new Unit(nowAINo,type,nowAINo);
							if(TwoVTwo && nowAINo==3){
								unit.setCamp(0);
							}else if(TwoVTwo){
								unit.setCamp(1);
							}
						} else if (PLAYERLIST.get(nowAINo)==4) {
							type = type + 30;
							unit = new Unit(nowAINo,type,nowAINo);
							if(TwoVTwo && nowAINo==3){
								unit.setCamp(0);
							}else if(TwoVTwo){
								unit.setCamp(1);
							}
						} else if (PLAYERLIST.get(nowAINo)==5) {
							type = type + 40;
							unit = new Unit(nowAINo,type,nowAINo);
							if(TwoVTwo && nowAINo==3){
								unit.setCamp(0);
							}else if(TwoVTwo){
								unit.setCamp(1);
							}
						} else if (PLAYERLIST.get(nowAINo)==6) {
							type = type + 50;
							unit = new Unit(nowAINo,type,nowAINo);
							if(TwoVTwo && nowAINo==3){
								unit.setCamp(0);
							}else if(TwoVTwo){
								unit.setCamp(1);
							}
						} else if (PLAYERLIST.get(nowAINo)==7) {
							type = type + 60;
							unit = new Unit(nowAINo,type,nowAINo);
							if(TwoVTwo && nowAINo==3){
								unit.setCamp(0);
							}else if(TwoVTwo){
								unit.setCamp(1);
							}
						} else {
							unit = new Unit(nowAINo,type,nowAINo);
							if(TwoVTwo && nowAINo==3){
								unit.setCamp(0);
							}else if(TwoVTwo){
								unit.setCamp(1);
							}
						}
						unit.setState(1);
						unit.setAttackedflag(true);
						unit.setMovedflag(true);
						goldList.set(nowAINo, goldList.get(nowAINo)-cost);
						land.setHasUnit(true);
						land.setUnit(unit);
						
						aiNextGoldDo = 0;
					}
				}
			}
		}
	}
	
	private void setAiNextGoldDo(int nowAINo, int nowAICamp) {
		aiBuyUnit_TownNoUnit(nowAINo);
		aiBuyUnit_TownHasUnit(nowAINo, nowAICamp);
//		for (int i = 0; i < landList.size(); i++)
//		{
//			Land land = landList.get(i);
//			if (land.isHasTown() && land.getTown().getOwner()==nowAINo && land.getTown().getType()==1){
//				Town town = land.getTown();
//				List<Integer> stateList = town.getTownState();
//				int checkstate = (int)(Math.random()*stateList.size());
//				int state = stateList.get(checkstate);
//				if (aiNextGoldDo == 0) {
//					while (state!=1 && state!=2 && state!=3 && state!=81 && state!=84) {
//						checkstate = (int)(Math.random()*stateList.size());
//						state = stateList.get(checkstate);
//					}
//					aiNextGoldDo = state;
//				}
//				if (aiNextGoldDo == 1) {
//					aiBuyUnit(nowAINo, 1, 10);
//				} else if (aiNextGoldDo == 2) {
//					aiBuyUnit(nowAINo, 2, 10);
//				} else if (aiNextGoldDo == 3) {
//					aiBuyUnit(nowAINo, 3, 10);
//				} else if (aiNextGoldDo == 84) {
//					if (goldList.get(nowAINo)>=10) {
//						stateList.set(7, stateList.get(7)+1);
//						town.setTurnGoldUp(town.getTurnGoldUp()+3);
//						goldList.set(nowAINo, goldList.get(nowAINo)-10);
//						aiNextGoldDo = 0;
//					}
//				} else if (aiNextGoldDo == 81) {
//					if (goldList.get(nowAINo)>=10) {
//						stateList.set(6, stateList.get(6)+1);
//						stateList.set(2, 3);
//						goldList.set(nowAINo, goldList.get(nowAINo)-10);
//						aiNextGoldDo = 0;
//					}
//				}
//			}
//		}
	}

	private void logic(int nowAINo,int nowAICamp) {
		
		if (aiState == 0){
			
			for (int i = 0; i < landList.size(); i++)
			{
				Land land = landList.get(i);
				if (land.isHasTown() && land.getTown().getOwner()==nowAINo) {
					int owner = land.getTown().getOwner();
					int gold = goldList.get(owner)+land.getTown().getTurnGoldUp();
//					int sp = spList.get(owner)+land.getTown().getSPointUp();
					goldList.set(owner, gold);
//					spList.set(owner, sp);
				}
			}
			//
			goldList.set(nowAINo, goldList.get(nowAINo)+HARD);
//			spList.set(nowAINo, spList.get(nowAINo)+1);
			//
			
			myDraw();
			try {
				Thread.sleep(250);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			aiState = 1;
			return;

		} else if (aiState == 1){

			setAiNextGoldDo(nowAINo, nowAICamp);
			
			
			// ������λ��
			int hasunit = 0;
			// �з���λ��
			int ensunit = 0;
			for (int i = 0; i < landList.size(); i++)
			{
				Land land = landList.get(i);
				if (TwoVTwo){
					if (land.isHasUnit() && land.getUnit().getCamp()==nowAICamp && land.getUnit().getState()==0) {
						hasunit++;
					}
					if (land.isHasUnit() && land.getUnit().getCamp()!=nowAICamp) {
						ensunit++;
					}
				}
				else{
					if (land.isHasUnit() && land.getUnit().getOwner()==nowAINo && land.getUnit().getCamp()==nowAICamp && land.getUnit().getState()==0) {
						hasunit++;
					}
					if (land.isHasUnit() && land.getUnit().getOwner()!=nowAINo && land.getUnit().getCamp()!=nowAICamp) {
						ensunit++;
					}
				}
			}
			if (hasunit>=ensunit || hasunit>=5) {
				for (int i = 0; i < landList.size(); i++)
				{
					Land land = landList.get(i);
					if (land.isHasUnit() && land.getUnit().getOwner()==nowAINo && land.getUnit().getState()==0) {
						land.getUnit().setState(2);
					}
				}
			}
			// ��λ�ж�
			for (int i = 0; i < landList.size(); i++)
			{
				Land land = landList.get(i);
				if (land.isHasUnit() && land.getUnit().getOwner()==nowAINo && !land.getUnit().isMovedflag()) {
					

					if (land.getUnit().getState()==0){
						// ������Χ�ڵз�
						aiUnitState0Action(land, nowAINo, nowAICamp);
						// ��ԭ
						afterUnitAction(land);
					} else if (land.getUnit().getState()==2) {
						aiUnitState0Action(land, nowAINo, nowAICamp);
						if (land.isHasUnit() && !land.getUnit().isAttackedflag()) {
							aiUnitState2Action(land, nowAINo, nowAICamp);
						}
						afterUnitAction(land);
					}
				}
			}
			aiState = 2;
			return;
			
		} else if (aiState == 2){
			
			for (int i = 0; i < landList.size(); i++)
			{
				Land land = landList.get(i);
				land.setHasSelected(false);
				land.setCanMove(false);
				if (land.isHasUnit()) {
					
					// δ�ж���λ�����ظ�
					if (land.getUnit().getOwner()==nowAINo && !land.getUnit().isMovedflag()) {
						int life = land.getUnit().getLife();
						int maxlife = land.getUnit().getMaxlife();
						life = life+1;
						if (life > maxlife) {
							life = maxlife;
						}
						land.getUnit().setLife(life);
					}
					if (land.getUnit().getOwner()==nowAINo && land.getUnit().isRecover()) {
						int life = land.getUnit().getLife();
						int maxlife = land.getUnit().getMaxlife();
						life = life+2;
						if (life > maxlife) {
							life = maxlife;
						}
						land.getUnit().setLife(life);
					}
					
					land.getUnit().setMovedflag(false);
					land.getUnit().setAttackedflag(false);
				}
			}

			if (nowAINo == MAXAI) {
				AIflag = false;
				aiNo = 1;
			} else {
				aiNo++;
			}
			aiState = 0;
			return;
		}
		
	}
	
	private void afterUnitAction(Land land) {
		for (int m = 0; m < landList.size(); m++)
		{
			Land landsetmove = landList.get(m);
			landsetmove.setCanMove(false);
			landsetmove.setHasSelected(false);
		}
		land.setCanMove(false);

		myDraw();
		try {
			Thread.sleep(250);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	private void aiUnitState2Action(Land land, int nowAINo, int nowAICamp) {

		int x = land.getX();
		int y = land.getY();
		
		int shortWay = 1000;
		Land landDecGo = null;
		
		for (int j = 0; j < landList.size(); j++)
		{
			Land landt = landList.get(j);
			if (landt.isHasTown() && landt.getTown().getOwner()!=nowAINo && landt.getTown().getCamp()!=nowAICamp) {
				int tx = landt.getX();
				int ty = landt.getY();
				if ((Math.abs(x-tx) + Math.abs(y-ty))<shortWay){
					shortWay = Math.abs(x-tx) + Math.abs(y-ty);
					landDecGo = landt;
				}
			}
		}
		
		List<Land> landwayList = moveRangeSet(land);
		
		myDraw();
		if (land.getUnit().getState()!=2) {
			try {
				Thread.sleep(250);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		shortWay = 1000;
	
		if (landDecGo==null) {
			for (int j = 0; j < landList.size(); j++)
			{
				Land landt = landList.get(j);
				if (landt.isHasUnit() && landt.getUnit().getOwner()!=nowAINo && landt.getUnit().getCamp()!=nowAICamp) {
					int tx = landt.getX();
					int ty = landt.getY();
					if ((Math.abs(x-tx) + Math.abs(y-ty))<shortWay){
						shortWay = Math.abs(x-tx) + Math.abs(y-ty);
						landDecGo = landt;
					}
				}
			}
			if (landDecGo==null) {
				return;
			}
		}
		
		//int tx = landDecGo.getX();
		//int ty = landDecGo.getY();

		//List<Land> landDecMoveList = new ArrayList<Land>();
		//landDecMoveList = findShortWay(land,landDecGo);
		
		//moveShortWay(land,landDecGo);
		
		Land moveLand = findfastway(landDecGo,landwayList);
				if (moveLand != null) {
				land.setHasSelected(true);
				move(land, moveLand);
				}
		
		
		//for (int m = 0; m < landwayList.size(); m++) {
		//	Land landcanmove = landwayList.get(m);
		//	if (!landcanmove.isHasUnit()) {
		//		int mx = landcanmove.getX();
		//		int my = landcanmove.getY();
		//		if ((Math.abs(tx-mx) + Math.abs(ty-my))<shortWay) {
		//			shortWay = Math.abs(tx-mx) + Math.abs(ty-my);
		//			landDecMoveList.clear();
		//			landDecMoveList.add(landcanmove);
		//		} else if ((Math.abs(tx-mx) + Math.abs(ty-my))==shortWay) {
		//			landDecMoveList.add(landcanmove);
		//		}
		//	}
		//}
		
		//if (landDecMoveList.size()>0){
		//	int moveNo = (int)(Math.random()*landDecMoveList.size());
		//	Land moveLand = landDecMoveList.get(moveNo);
		//	land.setHasSelected(true);
		//	move(land, moveLand);
		//}
	}
	
	private Land findfastway(Land landDecToGo, List<Land> landFromList)
    {
		List<Land> landwayList1 = new ArrayList<Land>();
		List<Land> landwayList2 = new ArrayList<Land>();
		landwayList1.add(landDecToGo);
		landwayList2.add(landDecToGo);

		for (int m = 1; m <= SIZE*SIZE; m++)
		{
		    int size = landwayList1.size();
		    for (int j = 0; j < size; j++)
		    {
	   	        Land landway = landwayList1.get(j);
		        List<Land> way = landway.getWay();
		        for (int n = 0; n < way.size(); n++)
		        {
		            Land landwayto = way.get(n);

		            if (landwayto.getLandType()==0) {
		                if(landFromList.contains(landwayto) && (!landwayto.isHasUnit())){
		                    return landwayto;
		                } else {
		                    landwayList1.add(landwayto);
		                }
		            }
		        }
		    }

		    List<Land> landwayListCopy = new ArrayList<Land>();
		    landwayListCopy.addAll(landwayList1);
		    landwayList1.removeAll(landwayList2);
		    landwayList2.clear();
		    landwayList2.addAll(landwayListCopy);
		}
		return null;
	}
	


	private void aiUnitState0Action(Land land, int nowAINo, int nowAICamp) {
		Unit unit = land.getUnit();
		int attackrange = unit.getAttackrange();
		// Ѱ���ƶ��ص�
		List<Land> landwayList = moveRangeSet(land);
		land.setCanMove(true);
		
		myDraw();
		try {
			Thread.sleep(250);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		for (int m = 0; m < landwayList.size(); m++) {
			Land landcanmove = landwayList.get(m);
			//if (landcanmove.isHasTown() && landcanmove.getTown().getOwner()!=nowAINo && !landcanmove.isHasUnit()) {
			// ����ռ�����
			if (landcanmove.isHasTown() && !landcanmove.isHasUnit()) {
				if (landcanmove.getTown().getType()==1 && landcanmove.getTown().getCamp()!=nowAICamp) {

					land.getUnit().setState(0);
					land.setHasSelected(true);
					move(land, landcanmove);
					land = landcanmove;
					land.getUnit().setState(1);
					for (int n = 0; n < landList.size(); n++)
					{
						Land landsetmove = landList.get(n);
						landsetmove.setCanMove(false);
						landsetmove.setHasSelected(false);
					}
					
					myDraw();
					
					// Ѱ���ƶ��ص�
					landwayList.clear();
					landwayList.add(land);
					try {
						Thread.sleep(250);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					return;
					
				} else if (landcanmove.getTown().getOwner()!=nowAINo && landcanmove.getTown().getCamp()!=nowAICamp) {
					land.getUnit().setState(0);
					land.setHasSelected(true);
					move(land, landcanmove);
					land = landcanmove;
					land.getUnit().setState(2);
					for (int n = 0; n < landList.size(); n++)
					{
						Land landsetmove = landList.get(n);
						landsetmove.setCanMove(false);
						landsetmove.setHasSelected(false);
					}
					
					myDraw();
					
					// Ѱ���ƶ��ص�
					landwayList.clear();
					land.setCanMove(true);
					landwayList.add(land);
				}
			}
		}

		// Ѱ�ҿɹ�����λ
		List<Land> landatkList = atkmoveRangeSet(land,landwayList);
		
		if (landatkList.size()>0){
			int atkNo = 0;
			int minlife = 1000;
			// ȷ����������
			for (int m = 0; m < landatkList.size(); m++)
			{
				Land landcanatk = landatkList.get(m);
				if (landcanatk.isHasUnit() && (landcanatk.getUnit().getLife()<minlife)) {
					minlife = landcanatk.getUnit().getLife();
					atkNo = m;
				}
			}
			Land landdecatk = landatkList.get(atkNo);
			boolean candonotmoveatk = false;
			List<Land> landstatkList = atkRangeSet(land);
			if (landstatkList.size()>0) {
				for (int m = 0; m < landstatkList.size(); m++)
				{
					Land landstatk = landstatkList.get(m);
					if (landdecatk.equals(landstatk)){
						candonotmoveatk = true;
					}
				}
			}
			// 
			if (attackrange>landdecatk.getUnit().getAttackrange() && candonotmoveatk) {
				int landrange = range(land, landdecatk);
				if (landrange<=landdecatk.getUnit().getAttackrange()){
					candonotmoveatk = false;
				}
			}
			// ����λ�Ƴ�
			Boolean townMoveAtk = false;
			if (candonotmoveatk) {
				if (land.isHasTown() && land.getTown().getOwner()==nowAINo && land.getTown().getType()==1){
					townMoveAtk = true;
					candonotmoveatk = false;
				}
			}
			//
			if (!candonotmoveatk) {
				List<Land> allcanatklandList = new ArrayList<Land>();
				for (int m = 0; m < landwayList.size(); m++)
				{
					Land landcanmove = landwayList.get(m);
					List<Land> canatklandList = new ArrayList<Land>();
					canatklandList.add(landcanmove);
					for (int n = 1; n <= attackrange; n++)
					{
						int size = canatklandList.size();
						for (int j = 0; j < size; j++)
						{
							Land landatkway = canatklandList.get(j);
							List<Land> way = landatkway.getWay();
							for (int k = 0; k < way.size(); k++)
							{
								Land landatkwayto = way.get(k);
								// TODO
								if (landatkwayto.getLandType()!=2) {
									if (!canatklandList.contains(landatkwayto)) {
										canatklandList.add(landatkwayto);
									}
									if (landatkwayto.equals(landdecatk)) {
										if (!landcanmove.isHasUnit()) {
											if (!allcanatklandList.contains(landcanmove)) {
												allcanatklandList.add(landcanmove);
											}
										}
									}
								}
							}
						}
					}
				}
				
				// �����������������
				if (allcanatklandList.size()>0 && (landdecatk.getUnit().getAttackrange()<land.getUnit().getAttackrange())) {
					List<Land> allcanatklandListCopy = new ArrayList<Land>();
					allcanatklandListCopy.addAll(allcanatklandList);
					for (int i = 0; i < allcanatklandList.size(); i++)
					{
						if((Math.abs(allcanatklandList.get(i).getX()-landdecatk.getX()) +
								Math.abs(allcanatklandList.get(i).getY()-landdecatk.getY()))
								<=landdecatk.getUnit().getAttackrange()){
							allcanatklandList.remove(i);
							i--;
						}
					}
					if (allcanatklandList.size()==0) {
						allcanatklandList.addAll(allcanatklandListCopy);
					}
				}
				// ����λ�Ƴ�
				if (townMoveAtk){
					List<Land> allcanatklandListCopy = new ArrayList<Land>();
					allcanatklandListCopy.addAll(allcanatklandList);
					allcanatklandList.remove(land);
					if (allcanatklandList.size()==0) {
						allcanatklandList.addAll(allcanatklandListCopy);
					}
				}
				
				if (allcanatklandList.size()>0) {
					int moveNo = (int)(Math.random()*allcanatklandList.size());
					Land moveLand = allcanatklandList.get(moveNo);
					land.setHasSelected(true);
					move(land, moveLand);
					battle(moveLand, landdecatk);
				} else {
					battle(land, landdecatk);
				}
			} else {
				battle(land, landdecatk);
			}
		}
	}
	
	@Override
	public void run() {

		if (!AIflag){
			myDraw();
		} else {
			new AITask().execute();
		}
		
			
	}
	
	private void startlogic() {
		while (AIflag){
			
			int camp = aiNo;
			if(TwoVTwo && aiNo==3){
				camp = 0;
			}else if(TwoVTwo){
				camp = 1;
			}
			logic(aiNo, camp);
			afterlogic();

		}
		

		for (int i = 0; i < landList.size(); i++)
		{
			Land land = landList.get(i);
			if (land.isHasTown() && land.getTown().getOwner()==0) {
				int owner = land.getTown().getOwner();
				int gold = goldList.get(owner)+land.getTown().getTurnGoldUp();
				goldList.set(owner, gold);
//				int sp = spList.get(owner)+land.getTown().getSPointUp();
//				spList.set(owner, sp);
			}
		}
		//
//		spList.set(0, spList.get(0)+1);
		//
		myDraw();
	}
	
	
	private void afterlogic() {

		myDraw();

	}
	


    private class AITask extends AsyncTask<URL, Integer, Long> {
        // Do the long-running work in here
        protected Long doInBackground(URL... urls) {
            long totalSize = 0;
            startlogic();
            return totalSize;
        }
    }
	    

    // save game
	private void saveGame() {
		//sp.edit().
		FileOutputStream fos = null;
		DataOutputStream dos = null;
		try {
			fos = MainActivity.instance.openFileOutput("save.himi", Context.MODE_PRIVATE);
			dos = new DataOutputStream(fos);
			dos.writeUTF(getSaveData());
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(fos != null){
					fos.close();
				}
				if(dos != null){
					dos.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	private String getSaveData(){
		String strlandList = "";
		for (int i=0; i<landList.size(); i++) {
			Land land = landList.get(i);
			strlandList = strlandList + land.getX();//1λ
			strlandList = strlandList + land.getY();//1λ
			if (land.isCanMove()){
				strlandList = strlandList + "1";
			} else {
				strlandList = strlandList + "0";
			}
			if (land.isCanBuy()){
				strlandList = strlandList + "1";
			} else {
				strlandList = strlandList + "0";
			}
			strlandList = strlandList + land.getLandType();//1λ
			if (land.isHasSelected()){
				strlandList = strlandList + "1";
			} else {
				strlandList = strlandList + "0";
			}
			if (land.isHasUnit()){
				strlandList = strlandList + "1";

				Unit unit = land.getUnit();
				if (unit.isMovedflag()){
					strlandList = strlandList + "1";
				} else {
					strlandList = strlandList + "0";
				}
				strlandList = strlandList + unit.getMovement();//1λ
				if (unit.isAttackedflag()){
					strlandList = strlandList + "1";
				} else {
					strlandList = strlandList + "0";
				}
				strlandList = strlandList + unit.getAttackrange();//1λ
				if (unit.getLife() < 10){
					strlandList = strlandList + "0" + unit.getLife();
				} else {
					strlandList = strlandList + unit.getLife();//2λ
				}
				strlandList = strlandList + unit.getMaxlife();//2λ
				strlandList = strlandList + unit.getAtk();//1λ
				strlandList = strlandList + unit.getDef();//1λ
				if (unit.isDoubleAtk()){
					strlandList = strlandList + "1";
				} else {
					strlandList = strlandList + "0";
				}
				if (unit.isJavelinAtk()){
					strlandList = strlandList + "1";
				} else {
					strlandList = strlandList + "0";
				}
				if (unit.isFatalAtk()){
					strlandList = strlandList + "1";
				} else {
					strlandList = strlandList + "0";
				}
				if (unit.isRampleAtk()){
					strlandList = strlandList + "1";
				} else {
					strlandList = strlandList + "0";
				}
				if (unit.isCannotDefCloAtk()){
					strlandList = strlandList + "1";
				} else {
					strlandList = strlandList + "0";
				}
				if (unit.isRecover()){
					strlandList = strlandList + "1";
				} else {
					strlandList = strlandList + "0";
				}
				strlandList = strlandList + unit.getType();//2λ
				strlandList = strlandList + unit.getOwner();//1λ
				strlandList = strlandList + unit.getCamp();//1λ
			} else {
				strlandList = strlandList + "0" + "00000000000000000000";
			}
			if (land.isHasTown()){
				strlandList = strlandList + "1";

				Town town = land.getTown();
				strlandList = strlandList + town.getType();
				
				if (town.getType() == 1){
					List<Integer> stateList = town.getTownState();
					if (stateList.size() == 8){
						for (int j = 0; j < stateList.size(); j++)
						{
							strlandList = strlandList + stateList.get(j);
						}
					}
				}
				else{
					strlandList = strlandList + "0000000086";
				}
				strlandList = strlandList + town.getOwner();//1λ
				strlandList = strlandList + town.getCamp();//1λ
				strlandList = strlandList + town.getTurnGoldUp();
				strlandList = strlandList + town.getSPointUp();
				strlandList = strlandList + town.getNation();
			} else {
				strlandList = strlandList + "0" + "0000000000000000";
			}
			strlandList = strlandList + "|";
		}
		return strlandList;
	}
    
	private void openGame() {
		FileInputStream fis = null;
		DataInputStream dis = null;
		
		try {
			fis = MainActivity.instance.openFileInput("save.himi");
			dis = new DataInputStream(fis);
			String a = dis.readUTF();
			setOpenData(a);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(fis != null){
					fis.close();
				}
				if(dis != null){
					dis.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void setOpenData(String readStr){
		List<Land> redLandList = new ArrayList<Land>();
		if (readStr.length() % 45 ==0)
		{
			String[] strList = readStr.split("\\|");
			for (int i = 0; i<strList.length; i++)
			{
				Land land = new Land(Integer.parseInt(String.valueOf(strList[i].charAt(0))),Integer.parseInt(String.valueOf(strList[i].charAt(1))));
				if("1".equals(String.valueOf(strList[i].charAt(2))))
				{
					land.setCanMove(true);
				}
				else
				{
					land.setCanMove(false);
				}
				if("1".equals(String.valueOf(strList[i].charAt(3))))
				{
					land.setCanBuy(true);
				}
				else
				{
					land.setCanBuy(false);
				}
				land.setLandType(Integer.parseInt(String.valueOf(strList[i].charAt(4))));
				if("1".equals(String.valueOf(strList[i].charAt(5))))
				{
					land.setHasSelected(true);
				}
				else
				{
					land.setHasSelected(false);
				}
				if("1".equals(String.valueOf(strList[i].charAt(6))))
				{
					land.setHasUnit(true);
					Unit unit = new Unit(0,0,0);
					if("1".equals(String.valueOf(strList[i].charAt(7))))
					{
						unit.setMovedflag(true);
					}
					else
					{
						unit.setMovedflag(false);
					}
					unit.setMovement(Integer.parseInt(String.valueOf(strList[i].charAt(8))));
					if("1".equals(String.valueOf(strList[i].charAt(9))))
					{
						unit.setAttackedflag(true);
					}
					else
					{
						unit.setAttackedflag(false);
					}
					unit.setAttackrange(Integer.parseInt(String.valueOf(strList[i].charAt(10))));
					unit.setLife(Integer.parseInt(String.valueOf(strList[i].charAt(11)))*10 + Integer.parseInt(String.valueOf(strList[i].charAt(12))));
					unit.setMaxlife(Integer.parseInt(String.valueOf(strList[i].charAt(13)))*10 + Integer.parseInt(String.valueOf(strList[i].charAt(14))));
					unit.setAtk(Integer.parseInt(String.valueOf(strList[i].charAt(15))));
					unit.setDef(Integer.parseInt(String.valueOf(strList[i].charAt(16))));
					if("1".equals(String.valueOf(strList[i].charAt(17))))
					{
						unit.setDoubleAtk(true);
					}
					else
					{
						unit.setDoubleAtk(false);
					}
					if("1".equals(String.valueOf(strList[i].charAt(18))))
					{
						unit.setJavelinAtk(true);
					}
					else
					{
						unit.setJavelinAtk(false);
					}
					if("1".equals(String.valueOf(strList[i].charAt(19))))
					{
						unit.setFatalAtk(true);
					}
					else
					{
						unit.setFatalAtk(false);
					}
					if("1".equals(String.valueOf(strList[i].charAt(20))))
					{
						unit.setRampleAtk(true);
					}
					else
					{
						unit.setRampleAtk(false);
					}
					if("1".equals(String.valueOf(strList[i].charAt(21))))
					{
						unit.setCannotDefCloAtk(true);
					}
					else
					{
						unit.setCannotDefCloAtk(false);
					}
					if("1".equals(String.valueOf(strList[i].charAt(22))))
					{
						unit.setRecover(true);
					}
					else
					{
						unit.setRecover(false);
					}
					unit.setType(Integer.parseInt(String.valueOf(strList[i].charAt(23)))*10 + Integer.parseInt(String.valueOf(strList[i].charAt(24))));
					unit.setOwner(Integer.parseInt(String.valueOf(strList[i].charAt(25))));
					unit.setCamp(Integer.parseInt(String.valueOf(strList[i].charAt(26))));
					land.setUnit(unit);
				}
				else
				{
					land.setHasUnit(false);
				}
				if("1".equals(String.valueOf(strList[i].charAt(27))))
				{
					land.setHasTown(true);
					Town town = new Town(0,0,0);

					town.setType(Integer.parseInt(String.valueOf(strList[i].charAt(28))));
					List<Integer> townState = new ArrayList<Integer>();
					if("1".equals(String.valueOf(strList[i].charAt(28))))
					{
						townState.add(Integer.parseInt(String.valueOf(strList[i].charAt(29))));
						townState.add(Integer.parseInt(String.valueOf(strList[i].charAt(30))));
						townState.add(Integer.parseInt(String.valueOf(strList[i].charAt(31))));
						townState.add(Integer.parseInt(String.valueOf(strList[i].charAt(32))));
						townState.add(Integer.parseInt(String.valueOf(strList[i].charAt(33))));
						townState.add(Integer.parseInt(String.valueOf(strList[i].charAt(34))));
						townState.add(Integer.parseInt("" + String.valueOf(strList[i].charAt(35) + String.valueOf(strList[i].charAt(36)))));
						townState.add(Integer.parseInt("" + String.valueOf(strList[i].charAt(37) + String.valueOf(strList[i].charAt(38)))));
					}
					else
					{
						townState.add(0);
						townState.add(0);
						townState.add(0);
						townState.add(0);
						townState.add(0);
						townState.add(0);
						townState.add(0);
						townState.add(86);
					}
					town.setTownState(townState);
					town.setOwner(Integer.parseInt(String.valueOf(strList[i].charAt(39))));
					town.setCamp(Integer.parseInt(String.valueOf(strList[i].charAt(40))));
					town.setTurnGoldUp(Integer.parseInt(String.valueOf(strList[i].charAt(41))));
					town.setSPointUp(Integer.parseInt(String.valueOf(strList[i].charAt(42))));
					town.setNation(Integer.parseInt(String.valueOf(strList[i].charAt(43))));
					land.setTown(town);
				}
				else
				{
					land.setHasTown(false);
				}
				redLandList.add(land);
			}
			for (int i=0; i<redLandList.size(); i++) {
				Land land = redLandList.get(i);
				int x = land.getX();
				int y = land.getY();

				List<Land> way = new ArrayList<Land>();
				
				for (int j=0; j<redLandList.size(); j++) {
					Land landt = redLandList.get(j);
					int xt = landt.getX();
					int yt = landt.getY();
					
					if (((x-1==xt)&&(y==yt)) || ((x+1==xt)&&(y==yt)) || ((y-1==yt)&&(x==xt)) || ((y+1==yt)&&(x==xt))) {
						way.add(landt);
					}
				}
				land.setWay(way);
			}
			landList = redLandList;
		}
		
	}
    
	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
	}


	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {

	}
}