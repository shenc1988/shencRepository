package com.example.testd;

import java.util.ArrayList;
import java.util.List;

public class Town {

	private List<Integer> townState = new ArrayList<Integer>();
	
	private int owner = 1;

	private int camp = 1;
	
	private int turnGoldUp = 3;
	private int SPointUp = 0;
	
	private int type = 1;
	
	private int nation = 1;

	public Town(int owner, int type, int camp) {
		this.setOwner(owner);
		this.setCamp(camp);
		
		this.setType(type);			
		this.setNation(nation);
		
		if (type==1) {
			this.townState.add(1);
			this.townState.add(2);
			this.townState.add(0);
			this.townState.add(0);
			this.townState.add(0);
			this.townState.add(0);
			this.townState.add(81);
			this.townState.add(84);

			this.setTurnGoldUp(3);
		} else {
			this.townState.add(0);
			this.townState.add(0);
			this.townState.add(0);
			this.townState.add(0);
			this.townState.add(0);
			this.townState.add(0);
			this.townState.add(0);
			this.townState.add(86);
			
			this.setTurnGoldUp(1);
		}
	}
	
	public int getOwner() {
		return owner;
	}

	public void setOwner(int owner) {
		this.owner = owner;
	}

	public int getCamp() {
		return camp;
	}

	public void setCamp(int camp) {
		this.camp = camp;
	}

	public int getTurnGoldUp() {
		return turnGoldUp;
	}

	public void setTurnGoldUp(int turnGoldUp) {
		this.turnGoldUp = turnGoldUp;
	}

	public List<Integer> getTownState() {
		return townState;
	}

	public void setTownState(List<Integer> state) {
		this.townState = state;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public int getSPointUp() {
		return SPointUp;
	}

	public void setSPointUp(int sPointUp) {
		SPointUp = sPointUp;
	}

	public int getNation() {
		return nation;
	}

	public void setNation(int nation) {
		this.nation = nation;
	}
}
