package com.example.testd;

public class Unit {

	private boolean movedflag = false;
	private int movement = 2;
	
	private boolean attackedflag = false;
	private int attackrange = 1;

	private int life;
	private int maxlife;
	
	private int atk;
	private int def;
	
	private boolean doubleAtk = false;
	private boolean javelinAtk = false;
	private boolean fatalAtk = false;
	private boolean rampleAtk = false;
	private boolean cannotDefCloAtk = false;
	private boolean recover = false;

	private int type = 1;

	private int owner = 1;

	private int camp = 1;
	
	//2����0����1��ֹ
	private int state = 0;
	
	public Unit(int owner, int type, int camp) {
		this.setOwner(owner);
		this.setCamp(camp);
		
		if (type==1) {
			// 10
			this.setType(1);
			this.setMaxlife(10);
			this.setLife(10);
			this.setAtk(2);
			this.setDef(2);
			this.setMovement(3);
			this.setAttackrange(1);
		} else if (type==2) {
			// 10
			this.setType(2);
			this.setMaxlife(10);
			this.setLife(10);
			this.setAtk(1);
			this.setDef(0);
			this.setMovement(3);
			this.setAttackrange(3);
		} else if (type==3) {
			// 15
			this.setType(3);
			this.setMaxlife(12);
			this.setLife(12);
			this.setAtk(3);
			this.setDef(2);
			this.setMovement(5);
			this.setAttackrange(1);
		} else if (type==4) {
			// 13
			this.setType(4);
			this.setMaxlife(12);
			this.setLife(12);
			this.setAtk(3);
			this.setDef(3);
			this.setMovement(3);
			this.setAttackrange(1);
		} else if (type==5) {
			// 17
			this.setType(5);
			this.setMaxlife(14);
			this.setLife(14);
			this.setAtk(4);
			this.setDef(2);
			this.setMovement(5);
			this.setAttackrange(1);
		} else if (type==11) {
			// 10
			this.setType(11);
			this.setMaxlife(10);
			this.setLife(10);
			this.setAtk(2);
			this.setDef(0);
			this.setMovement(3);
			this.setAttackrange(1);
			this.setDoubleAtk(true);
		} else if (type==12) {
			// 10
			this.setType(12);
			this.setMaxlife(10);
			this.setLife(10);
			this.setAtk(2);
			this.setDef(0);
			this.setMovement(3);
			this.setAttackrange(2);
		} else if (type==13) {
			// 10
			this.setType(13);
			this.setMaxlife(12);
			this.setLife(12);
			this.setAtk(2);
			this.setDef(0);
			this.setMovement(5);
			this.setAttackrange(1);
		} else if (type==14) {
			// 16
			this.setType(14);
			this.setMaxlife(17);
			this.setLife(17);
			this.setAtk(3);
			this.setDef(2);
			this.setMovement(3);
			this.setAttackrange(1);
		} else if (type==15) {
			// 16
			this.setType(15);
			this.setMaxlife(15);
			this.setLife(15);
			this.setAtk(4);
			this.setDef(2);
			this.setMovement(3);
			this.setAttackrange(1);
			this.setDoubleAtk(true);
		} else if (type==21) {
			// 10
			this.setType(21);
			this.setMaxlife(10);
			this.setLife(10);
			this.setAtk(1);
			this.setDef(3);
			this.setMovement(3);
			this.setAttackrange(1);
			this.setJavelinAtk(true);
		} else if (type==22) {
			// 10
			this.setType(22);
			this.setMaxlife(10);
			this.setLife(10);
			this.setAtk(1);
			this.setDef(1);
			this.setMovement(3);
			this.setAttackrange(2);
		} else if (type==23) {
			// 13
			this.setType(23);
			this.setMaxlife(12);
			this.setLife(12);
			this.setAtk(2);
			this.setDef(2);
			this.setMovement(5);
			this.setAttackrange(1);
		} else if (type==24) {
			// 12
			this.setType(24);
			this.setMaxlife(10);
			this.setLife(10);
			this.setAtk(3);
			this.setDef(3);
			this.setMovement(3);
			this.setAttackrange(1);
			this.setJavelinAtk(true);
		} else if (type==25) {
			// 14
			this.setType(25);
			this.setMaxlife(12);
			this.setLife(12);
			this.setAtk(4);
			this.setDef(3);
			this.setMovement(3);
			this.setAttackrange(1);
			this.setJavelinAtk(true);
		} else if (type==31) {
			// 10
			this.setType(31);
			this.setMaxlife(10);
			this.setLife(10);
			this.setAtk(2);
			this.setDef(2);
			this.setMovement(3);
			this.setAttackrange(1);
		} else if (type==32) {
			// 10
			this.setType(32);
			this.setMaxlife(10);
			this.setLife(10);
			this.setAtk(1);
			this.setDef(0);
			this.setMovement(3);
			this.setAttackrange(3);
		} else if (type==33) {
			// 15
			this.setType(33);
			this.setMaxlife(12);
			this.setLife(12);
			this.setAtk(2);
			this.setDef(3);
			this.setMovement(5);
			this.setAttackrange(1);
		} else if (type==34) {
			// 12
			this.setType(34);
			this.setMaxlife(10);
			this.setLife(10);
			this.setAtk(1);
			this.setDef(1);
			this.setMovement(3);
			this.setAttackrange(3);
			this.setDoubleAtk(true);
		} else if (type==35) {
			// 17
			this.setType(35);
			this.setMaxlife(10);
			this.setLife(10);
			this.setAtk(5);
			this.setDef(2);
			this.setMovement(3);
			this.setAttackrange(4);
			this.setCannotDefCloAtk(true);
		} else if (type==41) {
			// 10
			this.setType(41);
			this.setMaxlife(10);
			this.setLife(10);
			this.setAtk(2);
			this.setDef(2);
			this.setMovement(3);
			this.setAttackrange(1);
		} else if (type==42) {
			// 10
			this.setType(42);
			this.setMaxlife(10);
			this.setLife(10);
			this.setAtk(1);
			this.setDef(1);
			this.setMovement(5);
			this.setAttackrange(1);
		} else if (type==43) {
			// 15
			this.setType(43);
			this.setMaxlife(12);
			this.setLife(12);
			this.setAtk(3);
			this.setDef(3);
			this.setMovement(5);
			this.setAttackrange(1);
		} else if (type==44) {
			// 13
			this.setType(44);
			this.setMaxlife(10);
			this.setLife(10);
			this.setAtk(2);
			this.setDef(2);
			this.setMovement(3);
			this.setAttackrange(3);
		} else if (type==45) {
			// 17
			this.setType(45);
			this.setMaxlife(15);
			this.setLife(15);
			this.setAtk(5);
			this.setDef(3);
			this.setMovement(5);
			this.setAttackrange(1);
		} else if (type==51) {
			// 10
			this.setType(51);
			this.setMaxlife(10);
			this.setLife(10);
			this.setAtk(2);
			this.setDef(0);
			this.setMovement(3);
			this.setAttackrange(1);
			this.setFatalAtk(true);
		} else if (type==52) {
			// 10
			this.setType(52);
			this.setMaxlife(10);
			this.setLife(10);
			this.setAtk(1);
			this.setDef(0);
			this.setMovement(3);
			this.setAttackrange(3);
		} else if (type==53) {
			// 15
			this.setType(53);
			this.setMaxlife(12);
			this.setLife(12);
			this.setAtk(3);
			this.setDef(1);
			this.setMovement(3);
			this.setAttackrange(1);
			this.setFatalAtk(true);
		} else if (type==54) {
			// 13
			this.setType(54);
			this.setMaxlife(12);
			this.setLife(12);
			this.setAtk(2);
			this.setDef(0);
			this.setMovement(3);
			this.setAttackrange(4);
		} else if (type==55) {
			// 17
			this.setType(55);
			this.setMaxlife(15);
			this.setLife(15);
			this.setAtk(3);
			this.setDef(3);
			this.setMovement(5);
			this.setAttackrange(1);
			this.setRampleAtk(true);
		}else if (type==61) {
			// 10
			this.setType(61);
			this.setMaxlife(10);
			this.setLife(10);
			this.setAtk(1);
			this.setDef(1);
			this.setMovement(3);
			this.setAttackrange(1);
			this.setRecover(true);
		} else if (type==62) {
			// 10
			this.setType(62);
			this.setMaxlife(10);
			this.setLife(10);
			this.setAtk(0);
			this.setDef(0);
			this.setMovement(3);
			this.setAttackrange(4);
		} else if (type==63) {
			// 15
			this.setType(63);
			this.setMaxlife(12);
			this.setLife(12);
			this.setAtk(2);
			this.setDef(1);
			this.setMovement(5);
			this.setAttackrange(3);
		} else if (type==64) {
			// 13
			this.setType(64);
			this.setMaxlife(12);
			this.setLife(12);
			this.setAtk(2);
			this.setDef(2);
			this.setMovement(3);
			this.setAttackrange(1);
			this.setRecover(true);
		} else if (type==65) {
			// 18
			this.setType(65);
			this.setMaxlife(14);
			this.setLife(14);
			this.setAtk(3);
			this.setDef(3);
			this.setMovement(5);
			this.setAttackrange(1);
			this.setRampleAtk(true);
			this.setRecover(true);
		} else {
			this.setType(1);
			this.setMaxlife(10);
			this.setLife(10);
			this.setAtk(2);
			this.setDef(2);
			this.setMovement(2);
			this.setAttackrange(1);
		}
	}

	public boolean isMovedflag() {
		return movedflag;
	}

	public void setMovedflag(boolean movedflag) {
		this.movedflag = movedflag;
	}

	public int getOwner() {
		return owner;
	}

	public void setOwner(int owner) {
		this.owner = owner;
	}

	public int getCamp() {
		return camp;
	}

	public void setCamp(int camp) {
		this.camp = camp;
	}

	public int getMovement() {
		return movement;
	}

	public void setMovement(int movement) {
		this.movement = movement;
	}

	public boolean isAttackedflag() {
		return attackedflag;
	}

	public void setAttackedflag(boolean attackedflag) {
		this.attackedflag = attackedflag;
	}

	public int getAttackrange() {
		return attackrange;
	}

	public void setAttackrange(int attackrange) {
		this.attackrange = attackrange;
	}

	public int getLife() {
		return life;
	}

	public void setLife(int life) {
		this.life = life;
	}

	public int getMaxlife() {
		return maxlife;
	}

	public void setMaxlife(int maxlife) {
		this.maxlife = maxlife;
	}

	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
	}

	public int getAtk() {
		return atk;
	}

	public void setAtk(int atk) {
		this.atk = atk;
	}

	public int getDef() {
		return def;
	}

	public void setDef(int def) {
		this.def = def;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public boolean isDoubleAtk() {
		return doubleAtk;
	}

	public void setDoubleAtk(boolean doubleAtk) {
		this.doubleAtk = doubleAtk;
	}

	public boolean isJavelinAtk() {
		return javelinAtk;
	}

	public void setJavelinAtk(boolean javelinAtk) {
		this.javelinAtk = javelinAtk;
	}

	public boolean isFatalAtk() {
		return fatalAtk;
	}

	public void setFatalAtk(boolean fatalAtk) {
		this.fatalAtk = fatalAtk;
	}

	public boolean isRampleAtk() {
		return rampleAtk;
	}

	public void setRampleAtk(boolean rampleAtk) {
		this.rampleAtk = rampleAtk;
	}

	public boolean isCannotDefCloAtk() {
		return cannotDefCloAtk;
	}

	public void setCannotDefCloAtk(boolean cannotDefCloAtk) {
		this.cannotDefCloAtk = cannotDefCloAtk;
	}

	public boolean isRecover() {
		return recover;
	}

	public void setRecover(boolean recover) {
		this.recover = recover;
	}
	
}
